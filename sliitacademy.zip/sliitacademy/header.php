<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta content='Homelands' property='og:title'/>
    <meta content='Find the perfect land for your need with homelands' property='og:description'/>
    <meta property="og:url" content="https://www.homelands.lk/"/>
    <meta property="og:image:type" content="image/jpeg,image/png" />
    <meta property="og:type" content="website">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;500&display=swap" rel="stylesheet"> 
     <!--link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous"-->
     <!--link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/fontawesome.min.css" rel="stylesheet"-->
     <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.14.0/css/all.css">
     <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.14.0/css/v4-shims.css">
     <script defer src="https://use.fontawesome.com/releases/v5.14.0/js/all.js"></script>
     <script defer src="https://use.fontawesome.com/releases/v5.14.0/js/v4-shims.js"></script>
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5f2ba5755c885a1b7fb6bd11/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
	

	<!-- site-url -->
		<script>
			var global_site_url = null;
			//window.global_site_url = global_site_url = document.location.href;
      			window.global_site_url = global_site_url = "<?php echo get_site_url(); ?>";
		</script>
	<!-- site-url -->
      <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <?php wp_head(); ?>
  
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-175002660-1"></script>
<script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());

gtag('config', 'UA-175002660-1');
</script>
<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window,document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '2652108555053989'); 
fbq('track', 'PageView');
</script>
<noscript>
<img height="1" width="1" 
src="https://www.facebook.com/tr?id=2652108555053989&ev=PageView
&noscript=1"/>
</noscript>
<!-- End Facebook Pixel Code -->
</head>

<body <?php body_class(); ?>>
  <!-- ******************* The Navbar Area ******************* -->
<div class="wrapper-fluid wrapper-navbar" id="wrapper-navbar" itemscope itemtype="http://schema.org/WebSite"> 
  
    <div id="top-header-i" class="header-contact">
		<span class="hd-span"><i class='fas fa-phone'></i><a href="tel:+94112888777">+94 112 888 777</a></span>
		<span class="hd-span"><i class='fas fa-envelope'></i><a href="mailto:info@homelands.lk">info@homelands.lk</a></span>
			<div class="font-a-wrapper">
			     <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar("Social Media") ) : ?>

			     <?php endif;?> 
				
			</div>
	</div>   
    <nav id="nav-dsc" class="navbar navbar-expand-md navbar-dark">   
      <div class="container-fluid">  
       <div class="row row-width">
           <div id="set-r" class="col-lg-3">		  
               <!-- Your site title as branding in the menu -->
          <?php if ( ! has_custom_logo() ) { ?>

            <?php if ( is_front_page() && is_home() ) : ?>

              <h1 class="navbar-brand mb-0"><a rel="home" href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" itemprop="url"><?php bloginfo( 'name' ); ?></a></h1>
              
            <?php else : ?>

              <a class="navbar-brand" rel="home" href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" itemprop="url"><?php bloginfo( 'name' ); ?></a>
            
            <?php endif; ?>
            
          
          <?php } else {
            the_custom_logo();
          } ?><!-- end custom logo -->
           </div>
            <div class="col-lg-9" id="set-space-hd">
                          
             
                <button class="navbar-toggler d-block d-lg-none ml-auto mr-3" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                   <span class="navbar-toggler-icon"></span>
                </button>

        <!-- The WordPress Menu goes here -->
                  <?php wp_nav_menu(
                      array(
                        'theme_location'  => 'primary',
                        'container_class' => 'navbar-collapse',
                        'container_id'    => 'navbarNavDropdown',
                        'menu_class'      => 'navbar-nav',
                        'fallback_cb'     => '',
                        'menu_id'         => 'primary',
                        'walker'          => new WP_Bootstrap_Navwalker(),
                      )
                  ); ?>
      </div>
      </div><!-- .container -->
     
           </div>
        </div>
         

       

    </nav><!-- .site-navigation -->
	<div id="myNav" class="overlay">
      <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
      <div class="overlay-content">
	
        <?php wp_nav_menu(
                      array(
                        'theme_location'  => 'primary',
                        'container_class' => 'navbar-collapse',
                        'container_id'    => 'navbarNavDropdown',
                        'menu_class'      => 'navbar-nav',
                        'fallback_cb'     => '',
                        'menu_id'         => 'primary',
                        'walker'          => new WP_Bootstrap_Navwalker(),
                      )
                  ); ?>
		<div id="c-mobile-d" class="col-12 col-lg-4">
	 			  
				   <div class="row m-t-40">
					
				  <div class="col-12 col-md-12 set-text-left">
					<div class="">
						<span></span>
						<div class="row r-f-space">
							<div class="col-lg-2">
							  <i class="fa fa-phone"></i>
							</div>
							<div class="col-lg-10 font-s">
								  <div><a href="tel:+94112888777">+94 112 888 777</a>  </div>
					        </div>
						</div>
						<div>
						   <img class="footer-logo" src="<?php echo site_url();?>/wp-content/uploads/2020/07/footer-logo.png"/>

						</div>
					</div>
					 
					
					</div>
				  </div>
				 			  
		        </div> 
      </div>
  
    </div>
    <div class="open-mobile" onclick="openNav()">&#9776; </div>

<div id="b-b-set" class="inner-box-lower row">
	
	<div class="col-4 text-center">
	<img src="<?php echo site_url();?>/wp-content/uploads/2020/07/pay-online-1.png"/>
	<p>
		Pay Online
		</p>
	</div>
	<div class="col-4 text-center">
		<a href="lands"><div class="menu-mid"> </div></a>
		<p>
		View Lands
		</p>
	</div>
	<div class="col-4 text-center">
	<a href="reservation-form"><img src="<?php echo site_url();?>/wp-content/uploads/2020/07/reserve.png"/></a>
	<a href="reservation-form"><p>	Reserve Now	</p></a>

	</div>
	
</div>

<script>
//window.FontAwesomeConfig = { autoReplaceSvg: false }

// Add active class to the current button (highlight it)
var header = document.getElementById("primary");
var btns = header.getElementsByClassName("menu-item");
for (var i = 0; i < btns.length; i++) {
  btns[i].addEventListener("click", function() {
  var current = document.getElementsByClassName("active");
  current[0].className = current[0].className.replace(" active", "");
  this.className += " active";
  });
}
function openNav() {
  document.getElementById("myNav").style.height = "100%";
}

function closeNav() {
  document.getElementById("myNav").style.height = "0%";
}

$(function () {
  $(document).scroll(function () {
    var $nav = $("#nav-dsc");
    $nav.toggleClass('scrolled', $(this).scrollTop() > $nav.height());
  });
});
</script>