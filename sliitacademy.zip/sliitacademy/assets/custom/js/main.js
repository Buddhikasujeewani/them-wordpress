jQuery(document).ready(function() {
  jQuery("#owl-demo").owlCarousel({
        items:1,
        loop:true,
        nav: true,
        margin:10,
        animateOut: 'fadeOut',
        autoplay:true,
        autoplayTimeout:5000,
        autoplayHoverPause: false
  
  });
});
jQuery(document).ready(function() {
  jQuery("#owl-demo1").owlCarousel({
        items:1,
        loop:true,
        nav: true,
        margin:10,
        animateOut: 'fadeOut',
        autoplay:true,
        autoplayTimeout:5000,
        autoplayHoverPause: false
  
  });
});
jQuery(document).ready(function() {
jQuery('.awards').owlCarousel({
    items:3,
    loop:true,
    nav: true,
    margin:0,
   responsive:{
        0:{
            items:1
        },
        900:{
            items:1
        },
        1000:{
            items:3
        }
    }
});
});
jQuery(document).ready(function() {
jQuery('.associate').owlCarousel({
  
    loop:true,
    nav: true,
    dot:true,
    margin:10,
   responsive:{
        0:{
            items:1
        },
        900:{
            items:3
        },
        1000:{
            items:6
          
        }
    }
});
});

jQuery(document).ready(function() {
  jQuery("#owl-demo-1").owlCarousel({
        items:1,
        loop:true,
        nav: true,
        margin:10,
        animateOut: 'fadeOut',
        autoplay:true,
        autoplayTimeout:5000,
        autoplayHoverPause: false
  
  });
});
jQuery(document).ready(function() {
  jQuery("#owl-demo-news").owlCarousel({
        items:1,
        loop:true,
        nav: true,
        margin:10,
        animateOut: 'fadeOut',
        autoplay:true,
        autoplayTimeout:5000,
        autoplayHoverPause: false
  
  });
});
jQuery(document).ready(function() {
jQuery('.images-land').owlCarousel({
    center: true,
    items:3,
    loop:true,
    nav: true,
    dots:true,
    margin:0,
   responsive:{
        0:{
            items:1
        },
        900:{
            items:1
        },
        1000:{
            items:3
        }
    }
});
});
jQuery(document).ready(function() {
  jQuery("#owl-demo-3").owlCarousel({
        items:1,
        loop:true,
        nav: true,
        margin:10,
        animateOut: 'fadeOut',
        autoplay:true,
        autoplayTimeout:5000,
        autoplayHoverPause: false
  
  });
});

jQuery(document).ready(function() {
  jQuery(".owl-project1").owlCarousel({
        items:1,
        loop:true,
        nav: true,
        margin:10,
        animateOut: 'fadeOut',
        autoplay:true,
        autoplayTimeout:5000,
        autoplayHoverPause: false
  
  });
});


jQuery(document).ready(function() {
jQuery('.add-spec').owlCarousel({
    items:4,
    loop:false,
    margin:10,
	autoplay:true,
    autoplayTimeout:5000,
    autoplayHoverPause: false,
    responsive:{
        600:{
            items:4
        }
    }
});
});

jQuery(document).ready(function() {
jQuery('.home-house').owlCarousel({
    items:1,
    loop:true,
    margin:10,
	autoplay:false,
	 nav:true,
    autoplayTimeout:5000,
    autoplayHoverPause: false,
    responsive:{
        600:{
            items:1
        }
    }
});
});

jQuery(document).ready(function() {
jQuery('.sales-team').owlCarousel({
    loop:false,
    margin:10,
    nav:true,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:3
        },
        1000:{
            items:3
        },
		1200:{
			items:4
		}
    }
})
});


jQuery(document).ready(function() {
  jQuery("#owl-demo-test").owlCarousel({
        
        items:1,
        nav: true,
        margin:10,
        animateOut: 'fadeOut',
        autoplay:true,
        autoplayTimeout:5000,
        autoplayHoverPause: false
  
  });
});
