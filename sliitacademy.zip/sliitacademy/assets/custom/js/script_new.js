window.$ = window.jQuery = jQuery;

//var domain = document.URL;
//"http://homlands.weblankan.site";
 var domain = window.global_site_url;
//var domain = document.location.href;
console.log( "domain = " + domain );
var land_post_container_id = "#land_pots_container";
var select_district_id = "#district";
var select_city_id = "#city";

$(function(){
	"use strict";
	domain = window.global_site_url;
	filterDistricts();
	filterCities();
	$( select_district_id ).change(function(){
		console.log("change");
		filterCities();
	});
});

/* *** */
/*
function filterDistricts(){
	var uri = (domain + "/wp-json/my-custom-theme/v1/district/district-posts");
	var select_district = $( select_district_id );
	var select_city = $( select_city_id );
	select_district.empty();
	$.ajax({
		url: uri,
		method: "GET",
		data: {
            'city': select_city.val()
        },
		beforeSend: function( xhr ) {
			console.log("xhr");
		}
	}).done(function( data ) {
		//console.log( data );
		feedDistricts( data );
	}).fail(function( data ) {
		//console.log( "error" );
	}).always(function( data ) {
		//console.log( "complete" );
	});
}

function feedDistricts( district_data ){
	//console.log( district_data );
	var select_district = $( select_district_id );
	select_district.empty();
	$.each( district_data, function( key, value ) {
		//console.log( value );
		var opt_1 = $("<option>");
		opt_1.attr("value", value.post.post_name);
		opt_1.text( value.post.post_title );
		select_district.append( opt_1 );
	});
}

function filterCities(){
	var uri = (domain + "/wp-json/my-custom-theme/v1/city/district-city");
	var select_district = $( select_district_id );
	var select_city = $( select_city_id );
	select_city.empty();
	$.ajax({
		url: uri,
		method: "GET",
		data: {
			//'district': select_district.val()
		},
		beforeSend: function( xhr ) {
			console.log("xhr");
		}
	}).done(function( data ) {
		//console.log( data );
		feedCities( data );
	}).fail(function( data ) {
		//console.log( "error" );
	}).always(function( data ) {
		//console.log( "complete" );
	});
}

function feedCities( city_data ){
	//console.log( city_data );
	var select_city = $( select_city_id );
	select_city.empty();
	$.each( city_data, function( key, value ) {
		//console.log( value );
		var opt_1 = $("<option>");
		opt_1.attr("value", value.name);
		opt_1.text( value.name );
		select_city.append( opt_1 );
	});
}
*/
/* *** */

/* ********** */
/* *** */
function filterCities(){
	var uri = (domain + "/wp-json/my-custom-theme/v1/city/district-city");
	var select_district = $( select_district_id );
	var select_city = $( select_city_id );
	select_city.empty();
	$.ajax({
		url: uri,
		method: "GET",
		data: {
            'district': select_district.val()
        },
		beforeSend: function( xhr ) {
			console.log("xhr");
		}
	}).done(function( data ) {
		//console.log( data );
		feedCities( data );
	}).fail(function( data ) {
		//console.log( "error" );
	}).always(function( data ) {
		//console.log( "complete" );
	});
}

function feedCities( city_data ){
	//console.log( city_data );
	var select_city = $( select_city_id );
	select_city.empty();
	$.each( city_data, function( key, value ) {
		console.log( value );
		var opt_1 = $("<option>");
		opt_1.attr("value", value.post.ID);
		opt_1.text( value.post.post_title );
		select_city.append( opt_1 );
	});
}

function filterDistricts(){
	var uri = (domain + "/wp-json/my-custom-theme/v1/district/district-posts");
	var select_district = $( select_district_id );
	var select_city = $( select_city_id );
	select_district.empty();
	$.ajax({
		url: uri,
		method: "GET",
		data: {
			//'city': select_city.val()
		},
		beforeSend: function( xhr ) {
			console.log("xhr");
		}
	}).done(function( data ) {
		//console.log( data );
		feedDistricts( data );
	}).fail(function( data ) {
		//console.log( "error" );
	}).always(function( data ) {
		//console.log( "complete" );
	});
}

function feedDistricts( district_data ){
	//console.log( district_data );
	var select_district = $( select_district_id );
	select_district.empty();
	$.each( district_data, function( key, value ) {
		console.log( value );
		var opt_1 = $("<option>");
		opt_1.attr("value", value.term_id);
		opt_1.text( value.name );
		select_district.append( opt_1 );
	});
}
/* *** */
/* ********** */

/* *** */
function go_to_lands(){
	//
	var uri = (domain + "/land-search");
	var temp_uri = (domain + "/land-search");
	var select_district = $( select_district_id );
	var select_city = $( select_city_id );
	var select_district_val = $( select_district_id ).val();
	var select_city_val = $( select_city_id ).val();

    var query_param = "?";
    
	if( select_district_val ){
        if( (temp_uri.includes( query_param )) ){
           if( (temp_uri.localeCompare( uri ) == 0) ){
               temp_uri = temp_uri + "q_d=" + select_district_val;
           }else{
               temp_uri = temp_uri + "&q_d=" + select_district_val;
           }
        }else{
           temp_uri = temp_uri + query_param + "q_d=" + select_district_val;
        }
	}

    if( select_city_val ){
        if( (temp_uri.includes( query_param )) ){
           if( (temp_uri.localeCompare( uri ) == 0) ){
               temp_uri = temp_uri + "q_c=" + select_city_val;
           }else{
               temp_uri = temp_uri + "&q_c=" + select_city_val;
           }
        }else{
           temp_uri = temp_uri + query_param + "q_c=" + select_city_val;
        }
	}

	console.log( "uri = " + uri );
	console.log( "uri = " + temp_uri );
	window.open(temp_uri, '_blank', null, true);
}
/* *** */