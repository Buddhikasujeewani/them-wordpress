<?php

	/*
		Template Name: branch
	*/
   get_header();
    get_header('subpage');
?>

<section id="associat-s-1" data-aos="zoom-in">
  <div class="container m-t-40 m-b-50">
    <div class="row no-gutters">
      <div class="col-12 text-center m-b-50">
       <h2 id="header-d" class="h2-size-common"><span class="diff-color">Branch</span> Network</h2>	
	     <h4 class="common-h4"><?php echo get_field('sub_header');?> </h4>    
       <p><?php echo get_field('content');?></p>
      </div> 
	 </div> 	
  	 <?php echo do_shortcode('[branch]');?>
     
	</div>
</section>



<?php
  get_footer();
?>