<?php

	/*
		Template Name: show-projects
	*/

	get_header('subpage');
?>

<style>
.home-house {
    overflow: hidden;
}
#pro-s-3 .col-12.col-md-9.text-center,section#home-s-3 .col-12.col-md-9.text-center{
	padding-left:0!important;
	padding-right:0!important;
}

#header-d-w::before {
    content: '';
    color: #777;
    position: absolute;
    width: 210px;
    height: 30px;
    background-color: #ffcc00;
    top: 0;
    left: 378px;
}
#header-d-w::after {
    content: '';
    color: #777;
    position: absolute;
    width: 100px;
    height: 30px;
    background-color: #003399;
    top: 0;
    right: -242px;
}
#inner-row:nth-child(odd){
	flex-direction:row-reverse;
}
#inner-row:nth-child(odd){
	flex-direction:row-reverse;
}
#pro-s-3:nth-child(odd) .pro-row{
	flex-direction:row-reverse;	
}
#pro-s-3:nth-child(odd){
	background-color:#fff;
}
#pro-s-3:nth-child(odd)> .project-wrapper {
    background-color: #ffffff;
    color: #635c5c;
    position: absolute;
    top: 99px;
    right: unset;
    width: 482px;
    height: 387px;
    z-index: 2;
    padding: 20px;
    padding-top: 60px;
    left: 172px;
}
#pro-s-3:nth-child(odd)> .container-fluid.m-t-60.m-b-60>.pro-row.row.row1>.col-12.col-md-9.text-center>#map_canvas{
    position: absolute;
    bottom: 53px;
    z-index: 4;
    left: unset!important;
    right: 90px!important;
}
#pro-s-3:nth-child(odd)> .project-wrapper>#header-d-w::before {
    content: '';
    color: #777;
    position: absolute;
    width: 100px;
    height: 30px;
    top: -100px;
    right: unset;
    left: -192px;
}
#pro-s-3:nth-child(odd)> .project-wrapper>#header-d-w::after  {

    content: '';
    color: #777;
    position: absolute;
    width: 100px;
    height: 30px;
    background-color: #003399;
    top: -100px;
    right: unset;
    left: -92px;
}
#pro-s-3:nth-child(odd) .owl-nav{
	position: absolute;
    bottom: 20px;
    right: unset!important;
    left: -122px!important;
}
#pro-s-3:nth-child(odd) button.owl-prev,#pro-s-3:nth-child(odd) button.owl-next{
	border:1px solid #000;
}
#pro-s-3:nth-child(odd) button.owl-prev span,#pro-s-3:nth-child(odd) button.owl-next span{
	color:#000;
}
@media screen and (max-width:768px){
#pro-s-3:nth-child(odd)> .container-fluid.m-t-60.m-b-60>.pro-row.row.row1>.col-12.col-md-9.text-center>#map_canvas {
    position: absolute;
    bottom: 0!important;
    z-index: 4;
    left: unset!important;
    right: 15px!important;
}	
}
</style>


<section id="home-s-1">
    <div class="container">
		<div class="row row1">
			<div class="col-12 col-md-12 text-center">
			 <h2 class="h2-size-common"><span class="diff-color">About </span>Our Projects</h2>	
			 <h4 class="common-h4"><?php echo get_field('projects_sub_header');?></h4>
			<p><?php echo get_field('projects_description');?></p>			 
	        </div>	       
	    </div>
	</div>
</section>
<?php
$term = get_queried_object();
// Get the taxonomy's terms
$terms = get_terms(
    array(
        'taxonomy'   => 'wise_housing_projects',
        'hide_empty' => false,
    )
);

// Check if any term exists
if ( ! empty( $terms ) && is_array( $terms ) ) {
    // Run a loop and print them all
    foreach ( $terms as $term ) { ?>
    
     
  

<section id="pro-s-3">
    <div class="container-fluid m-t-60 m-b-60">		
	    <div id="" class="pro-row row row1">		   
			<div class=" col-12 col-md-9 text-center">
			  <div class="owl-carousel owl-theme home-house">
			  <?php
                if( have_rows('project_images',$term) ):
               while ( have_rows('project_images',$term) ) : the_row();
			   ?>
              
				<div class="item choose-img" style="background-image:url(<?php the_sub_field('project-set'); ?>);">		
					
				</div>
				<?php
                   endwhile;
				   else :
                   endif;

                ?>			
			  </div>
			   <div id="map_canvas">
			   <?php echo get_field('google_map', $term); ?>
			   </div>
			</div>	
	        <div class="col-12 col-md-3 text-center">
			 
			  			
	        </div>	            
	    </div>
	</div>
	<div class="project-wrapper">
		<h2 id="header-d-w" class="h2-size-common-w-s">   <?php echo $term->name; ?></h2>
        <h2 class="h2-size-common-w">   <?php echo get_field('project_location', $term); ?></h2>			
		<div class="d-wrapper">
		  
			<?php echo the_field('availability'); ?>
			 <p class="p-class"><?php echo $term->description;?></p>
			 <div class="available-p">
			   <p>Number of houses available : <?php echo get_field('housing_design', $term); ?></p>
			   <p>Number of designs : <?php echo get_field('houses_available', $term); ?></p>
			   <?php
               $colors = get_field('availability',$term);
               if( $colors ): 

     foreach( $colors as $color ):
        
         if($color=="Available"){?>
			 <div class="aval"><img src="<?php echo site_url();?>/wp-content/uploads/2020/04/sale.png"/></div>
		 <?php }
		 else{?>
			<div class="aval"><img src="<?php echo site_url();?>/wp-content/uploads/2020/04/sold-1.png"/></div> 
		 <?php }
		
     endforeach;

 endif; ?>
			
			 </div>
			 <?php 
			 $colors = get_field('availability',$term);
            if( $colors ): 
            foreach( $colors as $color ):        
            if($color=="Available"){?>
			 <a class="example_f" href="<?php echo esc_url( get_term_link( $term ) ) ?>" target="_blank"> <div id="explore-btn-news" class="button_cont" align="center"><div><img class="img-h" src="<?php echo site_url();?>/wp-content/uploads/2020/04/wise-btn.png"></div><div>Explore</div></div>  </a>
			 <?php }
		     endforeach;
              endif; ?>   
		</div>	
	</div>
</section>

<?php
  }
} 
?>

<section id="pro-s-6">   
    <div class="container m-t-60 m-b-60">
		<div class="row row1">
		    <div id="testi-space-1" class="col-12 col-md-12 text-center">
			   <h2 id="header-d" class="h2-size-common"><span class="diff-color">Meet</span> Our Sales Team</h2>			
			   <h4 class="common-h4"><?php echo get_field('sales_person_sub_header');?></h4>
			   <p><?php echo get_field('projects_description');?></p>
			</div>
			<div class="owl-carousel owl-theme sales-team">
				 <?php
					$loop = new WP_Query( array( 'post_type' => 'sales_team', 'paged' => $paged ) );
					if ( $loop->have_posts() ) :
					while ( $loop->have_posts() ) : $loop->the_post(); ?>
						<div class="item text-center">
						   <div id="ico-wrapper-sales">
							   <div class="image-wrapper" style="background-image:url(<?php echo get_field('sales_person_image');?>);"></div>
							   <h4><?php echo the_title();?></h4>
							    <?php
								if( have_rows('telephone_number') ):
						        while ( have_rows('telephone_number') ) : the_row();
			                    ?>
								  <p><?php echo the_sub_field('telephone_no');?></p>
								<?php
								   endwhile;
								   else :
								   endif;

                                ?>	 
						   </div>
						</div>
					<?php endwhile;
						endif;
						wp_reset_postdata();
					?>
			   
			</div>   
        </div>	   
    </div>
</section>
<?php
  get_footer();
?>