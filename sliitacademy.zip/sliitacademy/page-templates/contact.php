<?php



	/*

		Template Name: contact

	*/



   get_header();
    get_header('subpage');

?>
<style>
div#br-row p {
     margin-left: 0;
    margin-bottom: 5px;
}
</style>

<section id="contact-s-1" data-aos="zoom-in">

    <div class="container">
        <div class="row row1 no-gutters">	
			<div class="col-12 col-md-12 text-center">

		    	 <h2 id="header-d" class="h2-size-common"><span class="diff-color">Contact</span> Us</h2>	

				 <h4 class="common-h4">One step closer to finding the perfect land  </h4>   

			     <p>At Homelands, we strive to accommodate all your needs and requirements. We factor all these aspects in before enabling you to make a decision that you are comfortable with. To enable us to help you further get in touch with us to make your dream home land a reality. Please fill in the details of the form and submit it and a member of our team will be in contact with you shortly. </p>	

	        </div>

            <div id="set-border" class="col-12 col-md-3 text-center">

			    <div id="ico-wrapper">

				     <img class="ico-width" src="<?php echo site_url();?>/wp-content/uploads/2020/07/phone.png"/>

					

				</div>

			   <p><strong>Phone</strong></p>

			   <p>  <?php

                if( have_rows('telephone_number') ):

               while ( have_rows('telephone_number') ) : the_row();

			   ?>

			   <p><?php echo the_sub_field('no');?> </p>

                <?php

                   endwhile;

				   else :

                   endif;



                ?>	 </p>



	        </div>
	          <div id="set-border" class="col-12 col-md-3 text-center">

			    <div id="ico-wrapper">

				     <img class="ico-width" src="<?php echo site_url();?>/wp-content/uploads/2020/07/location.png"/>

					

				</div>

			   <p><strong>Location</strong></p>

			   <p><?php echo get_field('address');?> </p>



	        </div>		

	        <div id="set-border" class="col-12 col-md-3 text-center">

			    <div id="ico-wrapper">

				     <img class="ico-width" src="<?php echo site_url();?>/wp-content/uploads/2020/08/email.png"/>

					

				</div>

			   <p><strong>Email</strong></p>

			     <p><?php echo get_field('email');?> </p>

	        </div>

	         <div id="set-border" class="col-12 col-md-3 text-center">

			   <div id="ico-wrapper">

				     <img class="ico-width" src="<?php echo site_url();?>/wp-content/uploads/2020/07/fax.png"/>

					 

				</div>

			   <p><strong>Fax</strong></p>

			   <p><?php echo get_field('fax');?> </p>

	        </div>

	    </div>
	
</section>
<section id="contact-s-2" data-aos="zoom-in">

	<div class="container">
		
	
	    <div class="row row1 no-gutters">	
			 <h2 id="header-d" class="h2-size-common"><span class="diff-color">Office</span> Branches</h2>
			 
			
        </div>
	 <div class="row no-gutters">	
		
			 <?php echo do_shortcode('[branchp]');?>
			
        </div>
		
	
		</div>
	</section>
<section id="contact-s-3" data-aos="zoom-in">	
		<div class="container">
		<div class="row row1 no-gutters">	
			 <h2 id="header-d" class="h2-size-common"><span class="diff-color">Important </span> Numbers</h2>
			 
			
        </div>	
	 <div class="row no-gutters">	
		
			<?php

// check if the repeater field has rows of data
if( have_rows('important_numbers') ):

 	// loop through the rows of data
    while ( have_rows('important_numbers') ) : the_row();
		 ?>
<div id="" class="inner-shadow col-12 col-lg-4 set-text-left m-b-50">
            
             
             <div id="br-row1" class="row">
               <div class="col-2 col-md-1">
                 <i class="fa fa-user" aria-hidden="true"></i>
               </div>
               <div class="col-10 col-md-11">
                 <p><?php echo the_sub_field('name');?></p>
               </div>
             </div>
             <div id="br-row1" class="row">
               <div class="col-2 col-md-1">
                <i class="fa fa-phone" aria-hidden="true"></i>
               </div>
               <div class="col-10 col-md-11">
                 <p><?php echo the_sub_field('position');?></p>
               </div>
             </div>
            <div id="br-row1" class="row">
               <div class="col-2 col-md-1">
                <i class="fa fa-phone" aria-hidden="true"></i>
               </div>
               <div class="col-10 col-md-11">
                 <p><?php echo the_sub_field('number');?></p>
               </div>
             </div>
        </div>
       <?php
      

    endwhile;

else :

    // no rows found

endif;

?>
			
        </div>
		</div>
	</section>
<section id="contact-s-1" data-aos="zoom-in" class="aos-init aos-animate">
    <div class="container">
        <div class="row row1 no-gutters">	
			<div class="col-12 col-md-12 text-center">
		    	  <h2 id="header-d" class="h2-size-common"><span class="diff-color">Get in touch</span> with us</h2>
	        </div>
	   	    </div>
		<div class="row row1">
	        <div class="col-12 col-md-12">
	        	<?php echo  do_shortcode('[contact-form-7 id="15" title="Contact form 1"]');?>
		     </div>
	    </div>
	</div>
</section>
	
<section id="abt-s-4">
<?php echo get_field('google_map');?>
  

</section>



<?php

  get_footer();

?>