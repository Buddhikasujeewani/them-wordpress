<?php
	/*

		Template Name: career

	*/

   get_header();
    get_header('subpage');

?>
<style>
.nav-pills-custom .nav-link.active {
    color: #f4892c;
    background: #fff;
}

.nav-pills-custom .nav-link.active {
    color: #f4892c;
    background: #fff;
}

</style>
<section id="career-s-1">
  <div class="container m-t-40 m-b-50">
    <div class="row no-gutters">
      <div class="col-12 text-center m-b-50">
       <h2 id="header-d" class="h2-size-common"><span class="diff-color">We are</span> Hiring</h2> 
         <h4 class="common-h4"><?php echo get_field('sub_header');?></h4>    
       <p><?php echo get_field('content');?></p>
      </div> 
     </div> 
       <div class="row">
            <div class="col-md-3">
                <!-- Tabs nav -->                
                  <div class="nav flex-column nav-pills nav-pills-custom" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                       <a class="nav-link mb-3 shadow active" id="v-pills-home-tab" data-toggle="pill" href="#v-pills-home" role="tab" aria-controls="v-pills-home" aria-selected="true">
                    <i class="fa fa-user-circle-o mr-2"></i>
                    <span class="font-weight-bold small text-uppercase">Sales and Marketing</span></a>  
                  </div>              
            </div>


            <div class="col-md-9">
                <!-- Tabs content -->
                <div class="tab-content" id="v-pills-tabContent">
                    <div class="tab-pane fade shadow rounded bg-white show active p-5" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
                       <img style="width:100%" src="http://homlands.weblankan.site/wp-content/uploads/2020/07/ad.png"/>
                    </div>
                    
                </div>
            </div>
        </div>  
    </div>
</section>





<?php

  get_footer();

?>