<?php



    /*

        Template Name: reservation
    */



   get_header();
     get_header('subpage');
?>


<section id="contact-s-1">

    <div class="container">

		<div class="row row1">

			<div class="col-12 col-md-12 text-center">

		    	 <h2 id="header-d" class="h2-size-common"><span class="diff-color">Submit your</span> reservation request </h2>	

					

	        </div>

	        <div class="col-12 col-md-12">

	        	<?php echo  do_shortcode('[contact-form-7 id="925" title="reserve"]');?>

			 

	        </div>

	    </div>
	    	

	</div>

</section>
