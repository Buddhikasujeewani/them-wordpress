<?php



    /*

        Template Name: front

    */



    get_header();

?>

<style>
html {
overflow-x: hidden
}
@media screen and (max-width:768px){

#home-s-3 .project-wrapper{

    min-height:560px;

}

}

</style>
<section id="home-banner">
  

<div class="sub-overlay"></div>
<div id="owl-demo" class="owl-carousel owl-theme owl-loaded owl-drag">
  <div class="owl-stage-outer">
  <div class="owl-stage">
    <?php echo do_shortcode('[home_banners]');?>
       
    </div>
</div>
</div>
</section>

<section id="home-s-1" data-aos="zoom-in">

    <div class="container">
      
           <div id="inner-filter" class="row">
          <div class="col-12 col-md-4">
            <select name="district" id="district">
                    <option value="">Show all</option>
                  </select>
          </div>
          <div class="col-12 col-md-4">
            <select name="city" id="city">
                    <option value="">Show all</option>
                  </select>
          </div>
            <div class="col-12 col-md-4">
            <button id="call-btn-s" onclick="go_to_lands();">Show Lands</button>
          </div>
          </div>
          

    <div class="row row1">

      <div class="col-12 col-md-12 set-text-left">      

           <h2 class="h2-size-common"><span class="diff-color">Latest</span> Projects</h2>  
            <h4 class="common-h4"><h4 class="common-h4"><?php echo get_field('latest_projects_sub_header');?> </h4>
          <p><?php echo get_field('latest_project_content');?> </p>

          </div>     

      </div>
      <div id="land-av" class="row row1">
        <?php echo do_shortcode('[lands_top]');?>
      
      </div>

       <div class="row row1">
      <div class="col-12 col-md-12 set-text-left">
        <a class="a-color" href="lands">View More <i class="fa fa-angle-double-right"></i></a>
      </div>
    </div>
        <div class="row row1">
      <div class="col-12 col-md-12 set-text-right">
        <h2 class="h2-size-common"><span class="diff-color">On Going </span> Projects<span class="diff-color">.</span></h2> 
          <h4 class="common-h4"><h4 class="common-h4"><?php echo get_field('on_going_projects_sub_header');?></h4>
          <p><?php echo get_field('on_going_project_content');?> </p>
          </div>  
      </div>
      <div id="land-av" class="row row1">

          <?php echo do_shortcode('[lands_bot]');?>
      </div>
    <div class="row row1">
      <div class="col-12 col-md-12 set-text-left">
        <a class="a-color" href="lands">View More <i class="fa fa-angle-double-right"></i></a>
      </div>
    </div>  
  </div>

</section>
<section id="home-s-2" data-aos="zoom-in">
    <div class="container m-t-60 m-b-60">
        <div class="row">
            <div class="col-12 col-md-12 set-text-left">
                    <h2 id="header-d" class="h2-size-common"><span class="diff-color">Why Are We </span>Unique!<span class="diff-color"></span></h2>
                    <h4 class="common-h4"><h4 class="common-h4"><?php echo get_field('why_we_are_unique_header');?></h4>
                    <p><?php echo get_field('why_are_we_unique_content');?></p>

            </div>
        </div>
        
        <div class="row">
       <?php
        if( have_rows('unique_points') ):
        while ( have_rows('unique_points') ) : the_row();
        ?>
          <div class="col text-center">
            <img src="<?php echo the_sub_field('icon');?> "/>    
            <h5><?php echo the_sub_field('header');?></h5>            
             <p><?php echo the_sub_field('description');?></p>
          </div>            
        <?php
        endwhile;
        else :
        endif;

              ?>   
            

        </div>

    </div>
<div class="left-side"></div>
<div class="right-side"></div>
</section>
<section id="home-banner-pro" data-aos="zoom-in">
   <div class="sub-overlay">
     <p><?php echo get_field('sales_small_content');?></p>
     <div class="big-t">Mega<br/>Sale </div>
     <!--div class=""><img src="<?php //echo site_url();?>/wp-content/uploads/2020/07/buy.png"/></div-->
   </div>
   
   <div id="owl-demo1" class="owl-carousel owl-theme owl-loaded owl-drag">     
    <div class="owl-stage-outer">
        <div class="owl-stage">
              <?php echo do_shortcode('[advertisement]');?> 
            
       </div>
    </div>   
  </div> 
</section>
<section id="home-s-4" data-aos="zoom-in">
    <div class="container m-t-60 m-b-60">
        <div class="row row1">
            <div class="col-12 set-text-right">
                <h2 id="header-d" class="h2-size-common"><span class="diff-color">Our </span>Achievements<span class="diff-color"></span></h2>
                <h4 class="common-h4"><h4 class="common-h4"><?php get_field('achievements_sub_header');?></h4>
                <p><?php echo get_field('achievements_content');?></p>

            </div>      
        </div>
        <div class="row row1">
            <div class="awards owl-carousel owl-theme owl-loaded owl-drag">     
                <div class="owl-stage-outer">
                    <div class="owl-stage">
                       <?php
                      if( have_rows('awards') ):
                      while ( have_rows('awards') ) : the_row();
                      ?>
                        <div class="owl-item">
                            <div class="item">
                               
                                <img src="<?php echo the_sub_field('image');?>"/>
                              
                                <p><?php echo the_sub_field('award_name');?>
                                </p>
                            </div>
                         </div>
                          <?php
                          endwhile;
                          else :
                          endif;

                           ?>                      
                       
                    </div>
                </div>
            </div>
        </div>
</section>
<section id="home-s-2" data-aos="zoom-in">
    <div class="container m-t-60 m-b-60">
        <div class="row row1">
            <div class="col-12 col-md-12 set-text-left">
                    <h2 id="header-d" class="h2-size-common"><span class="diff-color">News & </span>Events</h2>
                    <h4 class="common-h4"><h4 class="common-h4"><?php get_field('news_sub_header');?></h4>
                    <p><?php echo get_field('news_content');?></p>

            </div>
        </div>
        <div id="land-av" class="row row1">
              <?php echo do_shortcode('[news_home]');?>
            
        </div>
         <div class="row row1">
            <div class="col-12 col-md-12 set-text-right">
                <a class="a-color1" href="news-events">View More News <i class="fa fa-angle-double-right"></i></a>
            </div>
        </div>
        <div class="" style="text-align:center;margin:0 auto;margin-top:30px;">

</div> 
  </div>
    

            
           
        </div>
        
  
<div class="left-side"></div>
<div class="right-side"></div>
</section>
<section id="home-s-5" data-aos="zoom-in">
    <div class="container m-t-60 m-b-60">
        <div class="row row1">
            <div class="col-12 col-md-12 set-text-right">
               <h2 id="header-d" class="h2-size-common"><span class="diff-color">Our Associate</span> Companies<span class="diff-color">.</span></h2>
               <h4 class="common-h4"><?php echo get_field('associated_companies_sub_header');?></h4>
               <p><?php echo get_field('associated_companies_content');?></p>
            </div>              

        </div>
        <div class="row row1">
           <div class="associate owl-carousel owl-theme owl-loaded owl-drag">     
                <div class="owl-stage-outer">
                    <div class="owl-stage">
                        <?php 
                        $images = get_field('associated_companies');
                        $size = 'full'; // (thumbnail, medium, large, full or custom size)
                        if( $images ): ?>
                           
                                <?php foreach( $images as $image_id ): ?>
                                    
                                       <div class="owl-item">
                                          <div class="item">
                                              <img src="<?php echo $image_id; ?>"/>
                                              
                                          </div>
                                       </div>
                                    
                                <?php endforeach; ?>
                            
                        <?php endif; ?>
                        
                    </div>
                </div>
            </div>              

        </div>

    </div>

</section>

<section id="home-s-6" data-aos="zoom-in">

    <div class="overlay-b"></div>

    <div class="container m-t-60 m-b-60">

        <div class="row row1">

            <div id="testi-space-1" class="col-12 col-md-12 text-center">

               <h2 id="header-d" class="h2-size-common"><span class="diff-color">See What</span> People Say<span class="diff-color">.</span></h2>           

               <h4 class="common-h4"><?php echo get_field('testimonials_sub_header');?></h4>

            </div>

             <div id="owl-demo-test" class="owl-carousel owl-theme owl-loaded owl-drag">                

                <div class="owl-stage-outer">
                    <div class="owl-stage" style="transform: translate3d(0px, 0px, 0px); transition: all 0s ease 0s; width: 1120px;">
                        <div class="owl-item active">
                            <div class="row">  
                               <div class="test-item">               

                                    <div id="ico-wrapper-test" class="col-12">

                                        <div class="image-wrapper" style="background-image:url(<?php echo site_url();?>/wp-content/uploads/2020/07/5.png);" data-aos="flip-down">                     

                                        </div>  

                                        <div class="client-con">                    

                                        <p>Good Service. Things were done at time. Expect other things also in time. Thanks Home Lands.   </p>

                                        </div>  

                                        <div class="client-name">

                                          <p>Subhashini</p>

                                        </div>                  

                                    </div>                  

                                </div>
                               

                    
                                <div class="test-item test-item1">               

                                    <div id="ico-wrapper-test" class="col-12">

                                        <div class="image-wrapper" style="background-image:url(<?php echo site_url();?>/wp-content/uploads/2020/07/client2.png);" data-aos="flip-down">                     

                                        </div>  

                                        <div class="client-con">                    

                                        <p>I purchased a land at Eppawala Project belongs to Home lands. From my first visit on the project they helped me a lot.  So I recommended Home lands as the best place to purchase land.   </p>

                                        </div>  

                                        <div class="client-name">

                                          <p>D.W.S Kapilarathna </p>

                                        </div>                  

                                    </div>                  

                                </div>

                    
                                <div class="test-item test-item1">               

                                    <div id="ico-wrapper-test" class="col-12">

                                        <div class="image-wrapper" style="background-image:url(<?php echo site_url();?>/wp-content/uploads/2020/07/WhatsApp-Image-2020-07-16-at-8.49.27-AM.jpeg);" data-aos="flip-down">                 

                                        </div>  

                                        <div class="client-con">                    

                                        <p>Home Land is one of a best real estate company in Sri Lanka. While I was buying my property from them the Home Land made stress free for me from every corner. The service provided was professional, quick and Beyond my expectations. I would highly recommend Home Land for anyone.
</p>

                                        </div>  

                                        <div class="client-name">

                                          <p>Tharindu Fernando </p>

                                        </div>                  

                                    </div>                  

                                </div>
                                <div class="test-item">  
                                    <div id="ico-wrapper-test" class="col-12">
                                        <div class="image-wrapper" style="background-image:url(<?php echo site_url();?>/wp-content/uploads/2020/07/3.jpg.png);" data-aos="flip-down">   
                                        </div>  
                                        <div class="client-con">
                                            <p> I have purchased few lands from leading land sales company but
HOME LANDS  is the best real estate company.when I was buying my land from HOME LANDS they gave me excellent 
service. I recommended HOME LANDS for anyone for  their property deals. good luck
        </p>
                                        </div>
                                        <div class="client-name">
                                            <p>E.P.J.S.Edirisinghe </p>
                                        </div>
                                    </div>      

                                </div>
                    </div>
    </div>     

 </div>

   <img class="Quotte-s" src="<?php echo site_url();?>/wp-content/uploads/2020/07/home-s-2.png">

</section>



<?php

  get_footer();

?>

