<?php
/**
 * Template Name: News Page
 *
 * Template for displaying a page without sidebar even if a sidebar widget is published.
 *
 * @package understrap
 */

get_header();
$container = get_theme_mod( 'understrap_container_type' );
?>
<style>
#sub-page-header {
    min-height: 400px;
    background-image: url(http://192.168.8.101:2020/2019/March/IntelSolar/wp-content/uploads/2019/03/loan-for-solar.jpg);
    text-align: center;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-top: -97px;
}
	a{
		color:#fff;
	}
		a:hover{
		color:#008e45;
	}
</style>

<?php include 'main-templates/sub-page-header.php';?>



<div class="wrapper" id="full-width-page-wrapper">
  


  <div id="content">

    <div class="row">

      <div class="col-md-12 content-area" id="primary">

        <main class="site-main" id="main" role="main">

<?php
$paged = ( get_query_var('paged') ) ? get_query_var('paged') : 1;
$catquery = new WP_Query(array(
      'category_name' => 'Projects',
    'posts_per_page' => 6,
    'paged' => $paged
        ));
?>

<section id="news-s-2">
<div class="container m-t-50">
	<div class="row">
		  <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
			 
			  <div class="row">
    <?php while ($catquery->have_posts()) : $catquery->the_post();?>
				
    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6" id="news-contain">
			
      
       <div style="position:relative;">
		   
		
      <div class="news-image" style="width:100%;float:right;"></div>
	    <?php $thumbnail = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID),'full',false );?>
		   <div class="img-bg-p" style="background-image:url('<?php echo $thumbnail[0]?>');height:400px;margin-bottom:30px;" ></div>
    	<div class="add-back-news">
			<a id="set-id3" href="<?php the_permalink() ?>" rel="bookmark"><?php the_title(); ?></a>      
			  <div class="font-home-list"><?php echo substr(get_the_excerpt(),0, 200); ?>..</div>
			  <span  class="entry-date"><?php echo get_the_date(); ?></span>
			 <h3 class="news-link"><a id="link-style" href="<?php the_permalink() ?>" rel="bookmark"><strong>Read more <i class="fa fa-arrow-right"></i></strong></a></h3>
		   </div>
    
		
    
    
    </div>
	</div>
    <?php endwhile; ?>
  </div>   
			  

<div class="" style="text-align:center;margin:0 auto;margin-top:30px;">
<div class="pagination" style="display:flex;justify-content:center;margin-bottom:30px;">
    <?php
    echo paginate_links(array(
        'base' => str_replace(999999999, '%#%', esc_url(get_pagenum_link(999999999))),
        'total' => $catquery->max_num_pages,
        'current' => max(1, get_query_var('paged')),
        'format' => '?paged=%#%',
        'show_all' => false,
        'type' => 'plain',
        'end_size' => 2,
        'mid_size' => 1,
        'prev_next' => true,
        'prev_text' => sprintf('<i></i> %1$s', __('prev', 'text-domain')),
        'next_text' => sprintf('%1$s <i></i>', __('next', 'text-domain')),
        'add_args' => false,
        'add_fragment' => '',
    ));
    ?>
</div>
</div>  			  
			  
			  
		</div>
	
	</div>
 

</section>







        </main><!-- #main -->

      </div><!-- #primary -->

    </div><!-- .row end -->

  </div><!-- Container end -->

</div><!-- Wrapper end -->

<?php get_footer(); ?>
