<?php



	/*

		Template Name: sell

	*/



	   get_header();
    get_header('subpage');

?>


<section id="contact-s-1">

    <div class="container">

		<div class="row row1">

			<div class="col-12 col-md-12 text-center">

		    	 <h2 id="header-d" class="h2-size-common"><span class="diff-color">Submit Your</span> Inquiry</h2>	

				 <h4 class="common-h4">Find the best price for your land </h4>   

			     <p>With us at Homelands you can find the best price in the market for your land. Fill the form given below with all the accurate and needed details of your land and submit the form. We will be in contact with you shortly. </p>	

	        </div>

	        <div class="col-12 col-md-12">

	        	<?php echo  do_shortcode('[contact-form-7 id="77" title="sell"]');?>

			 

	        </div>

	    </div>
	    	

	</div>

</section>


<?php

  get_footer();

?>