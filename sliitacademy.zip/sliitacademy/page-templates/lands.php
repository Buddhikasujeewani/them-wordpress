<?php



    /*

        Template Name: lands
    */


   get_header();
    get_header('subpage');
?>
<section id="home-s-1">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-4">
                    <select name="district" id="district">
                        <option value="">Show all</option>
                    </select>
                </div>
                <div class="col-12 col-md-4">
                    <select name="city" id="city">
                        <option value="">Show all</option>
                    </select>
                </div>
                <div class="col-12 col-md-4">
                    <button id="call-btn-s" onclick="go_to_lands();">Show Lands</button>
                </div>



    
    </div>
    
<div class="row" id="land_pots_container">
</div>
        <div id="land-av" class="row row1">
            
    <?php

		
			
	$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
	//$wp_query = null;
			
    $loop = new WP_Query( array( 'post_type' => 'land', 'paged' => $paged, 'posts_per_page'=>12 ) );
    if ( $loop->have_posts() ) :
        while ( $loop->have_posts() ) : $loop->the_post(); ?>
            <div class="col-12 col-lg-4">
                <div class="inner-land">
                    <?php $status = get_field('status');

                      if($status == "Available"){
                        ?>
                        <div class="aval"></div>
                        <?php
                       }
                       else{
                        ?>
                       <div class="sold"></div> 
                       <?php }
                    ?>
                    <div class="inner-border"></div>
                    <?php $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' ); ?>
                    <div class="inner-land-img" style="background-image:url(<?php echo $image[0]; ?>);">
                        <div class="inner-m-l"></div>
                        <div class="land-logo"><img src="<?php echo get_field('land_icon');?>"/></div>
                    </div>
                    <div class="inner-text">
                        
                        <div class="row row">
                            <div class="col-12"><img src="http://homlands.weblankan.site/wp-content/uploads/2020/07/location-1.png"/></div>
                            
                        </div>
                        <div class="row">
                            <div class="col-12"><h4> <?php echo get_the_title();?> - <?php echo get_field('land_location');?></h4></div>
                            
                        </div>
                        <div class="row">
                            <div class="col-2"><img src="http://homlands.weblankan.site/wp-content/uploads/2020/06/money.png"/></div>
                            <div class="col-10 text-left"><p>LKR <?php $format = number_format(get_field('price_per_perch'), 0, '', ', '); echo $format; ?>  Onwards</p></div> 
                        </div>
                        <div class="row">
                            <div class="col-2"><img src="http://homlands.weblankan.site/wp-content/uploads/2020/07/plot.png"/></div>
                            <div class="col-10 text-left"><p>Total Blocks <?php echo get_field('total_plots');?></p> </div>
                        </div>
                    </div>
                    <a id="link-style" href="<?php the_permalink() ?>" rel="bookmark"><strong>Read more <i class="fa fa-arrow-right"></i></strong></a>                  
               </div>
            </div> 
     <?php endwhile;
       
    endif;
					   ?>
   <div class="pagination">
    <?php
    echo paginate_links(array(
        'base' => str_replace(999999999, '%#%', esc_url(get_pagenum_link(999999999))),
        'total' => $loop->max_num_pages,
        'current' => max(1, get_query_var('paged')),
        'format' => '?page=%#%',
        'show_all' => false,
        'type' => 'plain',
        'end_size' => 2,
        'mid_size' => 1,
        'prev_next' => true,
        'prev_text' => sprintf('<i></i> %1$s', __('prev', 'text-domain')),
        'next_text' => sprintf('%1$s <i></i>', __('next', 'text-domain')),
        'add_args' => false,
        'add_fragment' => '',
    ));
	    if( is_array( $pages ) ) {
            $paged = ( get_query_var('paged') == 0 ) ? 1 : get_query_var('paged');
            echo '<ul class="pagination">';
            foreach ( $pages as $page ) {
                    echo "<li>$page</li>";
            }
           echo '</ul>';
        }
    ?>
</div>
   <?php wp_reset_postdata();
    ?>
    
        
         
          
        </div>
        
    </div>

</section>

<?php

  get_footer();

?>