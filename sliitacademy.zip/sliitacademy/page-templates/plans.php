<?php
	/*

		Template Name: plans

	*/

   get_header();
    get_header('subpage');

?>
<style>
#inner-land{
    margin-top:0!important;
}
</style>
<section id="inner-land">
   <div id="brown-l" class="container-fluid">
        <div class="back-inner">    
          <div  class="row">
              <div class="col-12 col-md-12">
                  <h3 id="header-d" class="h2-size-common"><span class="diff-color">Payment</span> Terms</h3>  
               </div>
            </div>
            <div  class="row">
              <?php echo do_shortcode('[payment_function]');?>
            </div>
        </div>
    </div>
</section>





<?php

  get_footer();

?>