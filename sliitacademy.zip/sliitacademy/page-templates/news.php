<?php



	/*

		Template Name: news

	*/

   get_header();
    get_header('subpage');

?>



<section id="news-s-1">

  <div class="container m-t-40 m-b-50">

	<div class="row row1">
		    <div class="col-12 col-md-12 text-center">
			        <h2 id="header-d" class="h2-size-common"><span class="diff-color">News & </span>Events</h2>
			   		<h4 class="common-h4">Stay updated on our work</h4>
			   		<p>At Homelands we constantly explore new horizons and achieve new goals in order to bring more opportunities to our loyal clientele. Find and read our latest ventures and get updates on what we do here.</p>

			</div>
	    </div>
	    <div id="land-av" class="row row1">
	    	<?php echo do_shortcode('[news]');?>
            
	    </div>
	    <div class="" style="text-align:center;margin:0 auto;margin-top:30px;">
<div class="pagination" style="display:flex;justify-content:center;margin-bottom:30px;">
    <?php
    echo paginate_links(array(
        'base' => str_replace(999999999, '%#%', esc_url(get_pagenum_link(999999999))),
        'total' => $catquery->max_num_pages,
        'current' => max(1, get_query_var('paged')),
        'format' => '?paged=%#%',
        'show_all' => false,
        'type' => 'plain',
        'end_size' => 2,
        'mid_size' => 1,
        'prev_next' => true,
        'prev_text' => sprintf('<i></i> %1$s', __('prev', 'text-domain')),
        'next_text' => sprintf('%1$s <i></i>', __('next', 'text-domain')),
        'add_args' => false,
        'add_fragment' => '',
    ));
    ?>
</div>
</div> 
  </div>  
</section>


<?php

  get_footer();

?>