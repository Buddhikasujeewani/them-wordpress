<?php



	/*

		Template Name: search

	*/



   get_header();
    get_header('subpage');

?>

	<section id="home-s-1">
	    <div class="container">
	    
	
<div class="row" id="land_pots_container">
</div>
	    <div id="land-av" class="row row1">
	    	
    <?php


    /*
	$land_posts = array();
	$query_args = array();
	$meta_query = array();
    $land_posts_with_meta = array();
    
	if( (isset($_REQUEST['q_d'])) && (!empty($_REQUEST['q_d'])) ){
		//var_dump( $_REQUEST['district'] );
		//die();
//		$meta_query[] = array(
//			'key' => 'land_district',
//			'value' => $_REQUEST['q_d'],
//			'compare' => '='
//		);
	}

	if( (isset($_REQUEST['q_c'])) && (!empty($_REQUEST['q_c'])) ){
		//var_dump( $_REQUEST['city'] );
		//die();
		$meta_query[] = array(
			'key' => 'city',
			'value' => $_REQUEST['q_c'],
			'compare' => '='
		);
	}

	$query_args['post_type'] = 'land';

	if( $meta_query ){
		$query_args['meta_query'] = $meta_query;
	}

	$land_posts = get_posts( $query_args );

	$land_posts_with_meta = array_map("processPostData_GetMeta", $land_posts);
	*/
            
    /* ********************************************************************************** */      
	$land_posts = array();
	$query_args = array();
	$meta_query = array();
    $land_posts_with_meta = array();
    $cityObj = null;
    $districtObj = null;

	if( (isset($_REQUEST['q_c'])) && (!empty($_REQUEST['q_c'])) ){
        $cityObj = get_post( $_REQUEST['q_c'] );
        if( $cityObj ){
            $districtObj = get_the_terms( $cityObj->ID, 'land_district' );
        }
        
		$meta_query[] = array(
			'key' => 'city',
			'value' => $_REQUEST['q_c'],
			'compare' => '='
		);
	}

	$query_args['post_type'] = 'land';

	if( $meta_query ){
		$query_args['meta_query'] = $meta_query;
	}

	$land_posts = get_posts( $query_args );
    
    $land_posts_with_meta = array_map(function($land_post_obj) use ($cityObj, $districtObj) {
        return array(
            'post' => $land_post_obj,
            'meta' => get_post_meta( $land_post_obj->ID ),
            'city' => $cityObj,
            'district' => $districtObj
        );
    }, $land_posts);
            
    //print_r( $land_posts_with_meta );
    /* ********************************************************************************** */

	foreach ($land_posts_with_meta as $pp) {
	  	?>
			
	        <div class="col-12 col-lg-4">
 			    <div class="inner-land">
 			   <?php $status = $pp['meta']['status'][0];
                      if($status == "Available"){
                      	?>
                      	<div class="aval"></div>
                      	<?php
                       }
                       else if($status == "Ongoing"){
                        ?>
                        <div class="upcome"></div>
                       <?php
                       }
                       else{
                       	?>
                       <div class="sold"></div>	
                       <?php }
 			    	?>
			  	    <div class="inner-border"></div>
			  	    <?php $image = wp_get_attachment_url($pp['meta']['_thumbnail_id'][0]);?>
			     	<div class="inner-land-img" style="background-image:url(<?php echo $image; ?>);">
			     		<div class="inner-m-l"></div>
                                         <?php $image1 = wp_get_attachment_url($pp['meta']['land_icon'][0]);?>

			     		<div class="land-logo"><img src="<?php echo $image1; ?>"/></div>
			     	</div>
			     	<div class="inner-text">
				     	
				     	<div class="row row">
				     		<div class="col-12"><img src="<?php echo site_url();?>/wp-content/uploads/2020/07/location-1.png"/></div>
				     		
				     	</div>
				     	<div class="row">
				     		<div class="col-12"><h4> <?php echo $pp['post']->post_title;?> - <?php echo $pp['post']->land_location;?></h4></div>
				     		
				     	</div>
				     	<div class="row">
				     		<div class="col-2"><img src="<?php echo site_url();?>/wp-content/uploads/2020/06/money.png"/></div>
				     		<div class="col-10 text-left"><p>LKR <?php $format = number_format($pp['meta']['price_per_perch'][0], 0, '', ', '); echo $format; ?>  Onwards</p></div> 
				     	</div>
				     	<div class="row">
				     		<div class="col-2"><img src="<?php echo site_url();?>/wp-content/uploads/2020/07/plot.png"/></div>
				     		<div class="col-10 text-left"><p>Total Blocks <?php echo $pp['meta']['total_plots'][0];?></p> </div>
				     	</div>
			     	</div>
			     	<a id="link-style" href="<?php echo $pp['post']->guid ?>" rel="bookmark"><strong>Read more <i class="fa fa-arrow-right"></i></strong></a>			     	
			   </div>
            </div> 
	 <?php 
       }
       

    
   
    wp_reset_postdata();
    ?>
 	
 <?php if( !($land_posts_with_meta) ): ?> 
 <h6 style="color:#fff;"> Currently no lands in the  city you searched. Please contact us on +94 112 888 777 for further information. </h6>     
 <?php endif; ?>      
          
	    </div>
	    
	</div>

</section>

<?php

  get_footer();

?>


