    <style>
#sub-page-header{
background-image:url(<?php echo site_url("wp-content/uploads/2020/04/home-banner.png") ?>);
);
}
#sub-page-header{
<?php 
if((get_the_post_thumbnail_url())){
echo 'background-image:url('.get_the_post_thumbnail_url().');';
}

?>

}

</style>

<div id="sub-page-header" style="position:relative;">
  <div class="sub-overlay" style=""></div>
	<div class="sub-page-header-warpper">
		<div style="">
			<div class="title-area">
			      <?php the_title( '<h2 class="main-title">', '</h2>' ); ?>
				<div class="breadcrumb"><a href="<?php echo home_url(); ?>">Home</a>	&nbsp; / &nbsp;<?php the_title( '<h6 class="main-title">', '</h6>' ); ?></div> 
		        </div>
	    </div>
	</div>

</div>
