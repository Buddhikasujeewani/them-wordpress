
<?php



	/*

		Template Name: 404

	*/



   get_header();
    get_header('subpage');

?>

<style>

.sub-page-header-warpper{

	display:none;

}

#sub-page-header{
background-image:url(<?php echo site_url("/wp-content/uploads/2020/08/404.png") ?>);
);
}



</style>

<section id="s-404">

  <div class="container">

    <div class="row">

	   <div class="col-12 text-center">

	      <h1>Oops! That page can&rsquo;t be found.</h1>

		  <a href="https://www.homelands.lk/"><button id="s-404-btn">Go Back to Home Page</button></a>

	   </div>

	</div>

  </div>

</section>



<?php

  get_footer();

?>