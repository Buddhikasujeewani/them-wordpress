<?php

//includes
include_once( 'inc/class-wp-bootstrap-navwalker.php' );
include_once( 'inc/widgets.php' );
include_once( 'inc/shortcodes.php' );
// Actions & Filter Hooks
add_action( 'wp_enqueue_scripts', 'home_resources' );
add_theme_support( 'custom-logo' );

function selmo_logo() {
 add_theme_support( 'custom-logo');
  add_theme_support( 'title-tag' );
}

add_action( 'after_setup_theme', 'selmo_logo' );
function cc_mime_types($mimes) {
  $mimes['svg'] = 'image/svg+xml';
  return $mimes;
}
add_theme_support( 'post-thumbnails' );
add_filter('upload_mimes', 'cc_mime_types');
function _dj1988_single_img_loader($atts) {
    $a = shortcode_atts(array('id' => '', 'type' => 'thumb', 'class' => '', 'icon' => ''), $atts);
    if ($a["icon"]) {
        return  wp_get_attachment_image($a["id"],'thumbnail',TRUE,array("class" => $a['class'],"id"=>"img_".$a["id"]));
    } else {
        return  wp_get_attachment_image($a["id"], $a["type"], $a['icon'], array("class" => $a['class'],"id"=>"img_".$a["id"]));
    }
}

add_shortcode('s-img', '_dj1988_single_img_loader');
// Resources
function home_resources() {
    wp_register_style('wl-aos', 'https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css');
	wp_register_style('bootstrap-style', get_template_directory_uri() . '/assets/bootstrap/css/bootstrap.min.css' );
	wp_register_style('owl-carousal', get_template_directory_uri() . '/assets/owlcarousal/css/owl.carousel.min.css' );
	wp_enqueue_style( 'mytheme-custom', get_template_directory_uri() . '/assets/custom/css/custom.css' );
	wp_register_style('wl-fonts', 'https://fonts.googleapis.com/css2?family=Bangers&display=swap" rel="stylesheet"');
	wp_register_style('wl-fonts1', 'https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet"');
	wp_register_style('wl-fonts2', 'https://fonts.googleapis.com/css2?family=Cedarville+Cursive&display=swap" rel="stylesheet"');
	
    wp_enqueue_style( 'wl-aos' );
	wp_enqueue_style( 'bootstrap-style' );
	wp_enqueue_style( 'mytheme-custom' );
	wp_enqueue_style( 'owl-carousal' );
	wp_enqueue_style( 'wl-fonts' );
	wp_enqueue_style( 'wl-fonts1' );
	wp_enqueue_style( 'wl-fonts2' );
	

    wp_register_style('aos', 'https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js');
	wp_register_script('bootstrap', get_template_directory_uri().'/assets/bootstrap/js/bootstrap.min.js' );
	wp_register_script('owl-carousal', get_template_directory_uri().'/assets/owlcarousal/js/owl.carousel.min.js' );
	wp_register_script( 'main', get_template_directory_uri() . '/assets/custom/js/main.js');
	wp_register_script( 'main_land', get_template_directory_uri() . '/assets/custom/js/script_new.js');
	
	//wp_register_script('custom-js', get_template_directory_uri().'/home-lands/js/script_new.js',array(),NULL,true);
    //wp_enqueue_script('custom-js');

    //$wnm_custom = array( 'template_url' => get_bloginfo('template_url') );
    //wp_localize_script( 'custom-js', 'wnm_custom', $wnm_custom );

    wp_enqueue_script( 'aos');
	wp_enqueue_script( 'jquery' );
	wp_enqueue_script( 'bootstrap', array('jquery'), '', true );
	wp_enqueue_script( 'owl-carousal', array('jquery'), '', true );
	wp_enqueue_script( 'main', array ( 'jquery' ), '', true );
	wp_enqueue_script( 'main_land', array ( 'jquery' ), '', true );
	
}




// Menus
add_action( 'after_setup_theme', 'register_menu' );
function register_menu() {
	// register nav menus
	register_nav_menus(array(
		'primary' => __( 'Main Menu', 'selmo' ),
		'footer' => __( 'Footer Menu', 'selmo' )
	));
}




/* ***** */
function processPostData_GetMeta( $post ){
	return array(
		'post' => $post,
		'meta' => get_post_meta( $post->ID )
	);
}
/* ***** */


/* ***** */
function processPostData_GetTerm( $post ){
	$terms = array();
	$post_type = $post->post_type;
	$taxonomies = get_object_taxonomies($post_type);
	foreach ($taxonomies as $taxonomy) {        
		$terms[ $taxonomy ] = get_the_terms( $post->ID, $taxonomy );
	}
	
	return array(
		'post' => $post,
		'term' => $terms
	);
}

/* ***** */
//filter term [type = district]
add_action('rest_api_init', function () {
  register_rest_route( 'my-custom-theme/v1/district', 'district-posts/', array(
                'methods'  => 'GET',
                'callback' => 'get_city_function'
      ));
});

function get_city_function($request){
	$districts = array();
	$districts = get_terms( array(
		'taxonomy' => 'land_district',
	) );
	
	if( (isset($request['city'])) && (!empty($request['city'])) ){
		$post = get_post( $request['city'] );
		//$post = getCityByName( $request['city'] );
		//print_r( $post );
		//die();
		if ( !empty($post) ) {
			//
			$districts = processPostData_GetDistrict( $post );
			//var_dump($districts);
		}
	}
	
	if (empty($districts)) {
		return new WP_Error( 'empty_result', 'there is no result', array('status' => 404) );
    }
	
	$response = new WP_REST_Response( $districts );
    $response->set_status(200);
    return $response;
}

function getCityByName( $name ){
	$found_post = null;
	$posts = get_posts( array( 
		'name' => $name, 
		'post_type' => 'city'
	) );
	
	$found_post = $posts[0];
	return $found_post;
}

function processPostData_GetDistrict( $post ){
	return get_the_terms( $post->ID, 'land_district' );

}
/* ***** */

/* ***** */
//filter post [type = city]
add_action('rest_api_init', function () {
  register_rest_route( 'my-custom-theme/v1/city', 'district-city/', array(
                'methods'  => 'GET',
                'callback' => 'get_district_function'
      ));
});

function get_district_function($request){
	$tax_query = array();
    $query_args = array();
    $query_args['posts_per_page'] = -1;
    
	if( (isset($request['district'])) && (!empty($request['district'])) ){
		$tax_query[] = array(
			'taxonomy' => 'land_district',
			'field' => 'id',
			'terms' => array( $request['district'] )
		);
	}
	
    if( $tax_query ){
        $query_args['tax_query'] = $tax_query;
    }
    
    $query_args['post_type'] = 'city';
    
	$posts = get_posts( $query_args );
	
    if (empty($posts)) {
		return new WP_Error( 'empty_result', 'there is no result', array('status' => 404) );
    }
	
	$post_with_term = array_map("processPostData_GetTerm", $posts);
	
    $response = new WP_REST_Response( $post_with_term );
    $response->set_status(200);
    return $response;
}
/* ***** */

function custom_add_form_tag_customlist() {

    wpcf7_add_form_tag( array( 'customlist', 'customlist*' ), 

'custom_customlist_form_tag_handler', true );

}

function dynamic_field_values ( $tag, $unused ) {



    if ( $tag['name'] != 'menu-417' )

        return $tag;



    $args = array (

        'numberposts'   => -1,

        'post_type'     => 'land',

        'orderby'       => 'title',

        'order'         => 'ASC',

    );



    $custom_posts = get_posts($args);



    if ( ! $custom_posts )

        return $tag;



    foreach ( $custom_posts as $custom_post ) {



        $tag['raw_values'][] = $custom_post->post_title;

        $tag['values'][] = $custom_post->post_title;

        $tag['labels'][] = $custom_post->post_title;



    }



    return $tag;



}



add_filter( 'wpcf7_form_tag', 'dynamic_field_values', 10, 2);

?>
