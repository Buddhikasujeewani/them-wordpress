  

  <!-- ******************* Top Bar Area ******************* --> 
<div id="top-bar" style="position:relative;">
  <div class="top-inner">
      <div class="container">
        <div class="row no-gutters">
          <div class="col-12 col-md-8 col-lg-6 top-bar-left">
            <span><i class="fa fa-map-marker" aria-hidden="true"></i> 475, High-Level Road, Wijerama, Nugegoda</span>
      <span><i class="fa fa-envelope"></i> solar@intellpv.com</span>
      <span><i class="fa fa-phone"></i> +94 114 5555 95</span>
          </div>
          <div class="col-12 col-md-4 col-lg-6 top-bar-right">
                opopo0oo-
       
          </div>
       </div>
    </div>
   </div>    
</div>  
<!--div id="top-bar-mobile" style="position:relative;">
  <div class="top-inner">
      <div class="container">
        <div class="row no-gutters">
          <div class="col-12 top-bar-left">
			  <div><i class="fa fa-map-marker" aria-hidden="true"></i> 475, High-Level Road, Wijerama, Nugegoda </div>
              <div><i class="fa fa-envelope"></i> solar@intellpv.com</div>
              <div><i class="fa fa-phone"></i> +94 114 5555 95</div>
          </div>
          <div class="col-12 col-md-4 col-lg-6 top-bar-right">
        <!--span>
               <form role="search" method="get" id="searchform" class="searchform" action="<?php //echo esc_url( home_url( '/' ) ); ?>">
                  <div>
                    <div id="set1" class="input-group mb-3"  style="float:right;">
                  <label class="screen-reader-text" for="s"><?php _x( 'Search for:', 'label' ); ?></label>
                      <input type="text"  value="<?php //echo get_search_query(); ?>" name="s" id="s" class="form-control" placeholder="Search" aria-label="Search" aria-describedby="basic-addon2">
                         <div class="input-group-append">
                            <button class="btn btn-outline-secondary" id="searchsubmit">
                          <i class="fa fa-search"></i></button>
      
                               </div>
                     </div>
                 </div>
               </form>
          </span-->
			  <!--span class="footer-social"><i class="fa fa-facebook"></i></span>  
                   <span class="footer-social"><i class="fa fa-youtube-play"></i></span>
                    <span class="footer-social"><i class="fa fa-twitter"></i></span>
                   <span class="footer-social"><i class="fa fa-instagram"></i></span>
                   <span class="footer-social"><i class="fa fa-google-plus"></i></span>
       
          </div>
       </div>
    </div>
   </div>    
</div--> 
 