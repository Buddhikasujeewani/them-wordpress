    <!-- ******************* Top Bar Area ******************* --> 
  <div id="top-bar" style="position:relative;">
    <div class="top-inner">
        <div class="container-fluid">
          <div class="row row1 no-gutters">
            <div class="col-12 col-md-6 col-lg-6 top-bar-left">
              <span>Hospitality Business School</span>
            </div>
            <div class="col-12 col-md-6 col-lg-6 top-bar-right">
            <div class="row row1">
               <div class="col-12 col-md-6 col-lg-8 top-bar-inner-right">
                  <nav class="navbar navbar-expand-lg">    
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTop" aria-controls="navbarTop" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarTop">
          <?php
            wp_nav_menu( array(
              'theme_location'  =>  'topbar',
              'menu_class'    =>  'navbar-nav mr-auto',
              'container_class' =>  false
            ) );
          ?>
        </div>
      </nav>
               </div>
               <div class="col-12 col-md-6 col-lg-4 top-bar-right">
                  <span>Hotline<a href="tel:+940812234346">(+94) 081 223 4346 </a></span> 
               </div>
            </div>       
  		
         
            </div>
         </div>
      </div>
     </div>    
  </div>  
<!--div id="top-bar-mobile" style="position:relative;">
  <div class="top-inner">
      <div class="container">
        <div class="row no-gutters">
          <div class="col-12 top-bar-left">
			  <div><i class="fa fa-map-marker" aria-hidden="true"></i> 475, High-Level Road, Wijerama, Nugegoda </div>
              <div><i class="fa fa-envelope"></i> solar@intellpv.com</div>
              <div><i class="fa fa-phone"></i> +94 114 5555 95</div>
          </div>
          <div class="col-12 col-md-4 col-lg-6 top-bar-right">
        <!--span>
               <form role="search" method="get" id="searchform" class="searchform" action="<?php //echo esc_url( home_url( '/' ) ); ?>">
                  <div>
                    <div id="set1" class="input-group mb-3"  style="float:right;">
                  <label class="screen-reader-text" for="s"><?php _x( 'Search for:', 'label' ); ?></label>
                      <input type="text"  value="<?php //echo get_search_query(); ?>" name="s" id="s" class="form-control" placeholder="Search" aria-label="Search" aria-describedby="basic-addon2">
                         <div class="input-group-append">
                            <button class="btn btn-outline-secondary" id="searchsubmit">
                          <i class="fa fa-search"></i></button>
      
                               </div>
                     </div>
                 </div>
               </form>
          </span-->
			  <!--span class="footer-social"><i class="fa fa-facebook"></i></span>  
                   <span class="footer-social"><i class="fa fa-youtube-play"></i></span>
                    <span class="footer-social"><i class="fa fa-twitter"></i></span>
                   <span class="footer-social"><i class="fa fa-instagram"></i></span>
                   <span class="footer-social"><i class="fa fa-google-plus"></i></span>
       
          </div>
       </div>
    </div>
   </div>    
</div--> 
 