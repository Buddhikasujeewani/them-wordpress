<section id="footer-sec">
  <div class="container">   
     <div id="footer-content" class="row text-set1">
      <div class="col-12 col-lg-12">
        <img class="float-icon1" src="<?php echo site_url();?>/wp-content/uploads/2019/11/footer-vector.png">
      </div>
      <div class="col-12 col-lg-10">

         <?php
            wp_nav_menu( array(
              'theme_location'  =>  'footer',
              'menu_class'    =>  'navbar-nav mr-auto',
              'container_class' =>  false
            ) );
          ?>
       
     </div>
   </div> 
 <div class="row m-t-40">
   <div class="col-12 col-lg-6 set-text-left">
    <div class="">
     <img src="<?php echo site_url();?>/wp-content/uploads/2019/09/logo.png"/>
     <p>
      Indra Traders is a 40 years old total vehicle trading solution provider that includes vehicle sales, upgrading, service and spare parts and repairing. 
    Subscribe to our newsletter to know about the latest vehicle models and services.        </p>         

  </div>
  <h2 class="m-b-30"><strong>Contact Details</strong>  </h2>
  <div class="row m-t-5 m-b-5">
   <div class="col-12 col-lg-1"><i class="fa fa-phone m-r-10 icon-color"></i></div>
   <div class="col-12 col-lg-11"> <a href="tel:+940812234346">+94 081 223 4346</a></div>
 </div>
 <div class="row m-t-5 m-b-5">
   <div class="col-12 col-lg-1"><i class="fa fa-phone m-r-10 icon-color"></i></div>
   <div class="col-12 col-lg-11"><a href="tel:+94112341333">+94 112 341333-7 </a></div>
 </div>
 <div class="row row1 m-t-5 m-b-5">
	  <div class="col-12 col-lg-1"></div>
      <div class="col-12 col-lg-11">
		  <div class="set-text-left"><span>Call Us at</span>		
           <img class="wudth-icon-imo" src="<?php echo site_url();?>/wp-content/uploads/2019/11/imo.png"/> 
	     </div>
	 </div> 	
 </div>  

 <div class="row m-t-5 m-b-5">
   <div class="col-12 col-lg-1"><i class="fa fa-envelope m-r-10 icon-color"></i></div>
   <div class="col-12 col-lg-11"> <a href="mailto:info@indratraders.lk">info@indratraders.lk</a></div>
 </div>
 <div class="row m-t-5 m-b-5">
   <div class="col-12 col-lg-1"><i class="fa fa-map-marker m-r-10 icon-color" aria-hidden="true"></i></div>
   <div class="col-12 col-lg-11"> 
     <strong>Head Office</strong> <br/> 
     No.175,Katugastota Road 
     <br/> Kandy.</div>
   </div>
   <div class="row m-t-5 m-b-5">
     <div class="col-12 col-lg-1"><i class="fa fa-map-marker m-r-10 icon-color" aria-hidden="true"></i></div>
     <div class="col-12 col-lg-11"> 
       <strong>Colombo Branch</strong> <br/> 
       No. 131,W.A.D. Ramanayake Mawatha <br/>
       Colombo 02.
     </div>
   </div>



 </div>
 <div class="col-12 col-lg-6 set-text-right">
  <div class="">
   <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Findratraders.lk%2F&tabs=timeline&width=340&height=500&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="340" height="500" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

 </div>
</div>
 <div class="col-12 text-center m-t-20 m-b-20">
<span id="siteseal"><script async type="text/javascript" src="https://seal.godaddy.com/getSeal?sealID=oXwlghkaUGdPl99cM2fSP8ATEXcOE4GeyyEVKXWXH8RIZmljQgeknUQVqVUg"></script></span>	 
 </div> 
</div>
</div>      
</section>
<section id="set-banks">
  <div class="container p-t-50 p-b-50">
 <div class="row m-t-40">
 <div class="col-12 col-lg-6 set-text-left">
  <div class="it-header">Our Bank Partners</div>
  <div class="row">
   <div class="col-3 col-lg-3 set-text-left"><img data-toggle="modal" data-target="#myModalhnb" src="<?php echo site_url();?>/wp-content/uploads/2019/09/hnb-new.png"/></div> 
   <div class="col-3 col-lg-3 set-text-left"><img data-toggle="modal" data-target="#myModalboc" src="<?php echo site_url();?>/wp-content/uploads/2019/09/new-boc.png"/></div> 
   <div class="col-3 col-lg-3 set-text-left"><img data-toggle="modal" data-target="#myModalsampath" src="<?php echo site_url();?>/wp-content/uploads/2019/09/new-sampath.png"/></div>
   <div class="col-3 col-lg-3 set-text-left"><img data-toggle="modal" data-target="#myModalseylan" src="<?php echo site_url();?>/wp-content/uploads/2019/09/seylan-1.png"/></div>          
 </div>
</div>
<div class="col-12 col-lg-6 set-text-left">
  <div class="it-header">Our Financial Partners</div>
  <div class="row">
     <div class="col-6 col-lg-3 set-text-left"><img data-toggle="modal" data-target="#myModalsampathf" src="<?php echo site_url();?>/wp-content/uploads/2019/09/siyapatha.png"/></div> 
     <div class="col-6 col-lg-3 set-text-left"><img data-toggle="modal" data-target="#myModalsinger" src="<?php echo site_url();?>/wp-content/uploads/2019/11/finance.png"/></div>
  </div> 
</div>          
</div>
  </div>    
</section>
<section>
  <div class="footer-text">
    Copyright © <?php echo date("Y") ?> - <a href="#">Indra Traders </a> - All Rights Reserved. Concept, Design &amp; Development by <a href="http://www.weblankan.com/">Web Lankan</a>
  </div> 
</section>
<div class="modal fade" id="myModalhnb" role="dialog">
    <div class="modal-dialog modal-dialog-centered">    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>        
        </div>
        <div class="modal-body">
         <div class="bank1">
         <!-- Copy & Pasted from YouTube -->
         <img src="<?php echo site_url();?>/wp-content/uploads/2019/11/hb-leasing.png"/>
       </div>   
        </div>       
      </div>      
    </div>
</div>
<div class="modal fade" id="myModalboc" role="dialog">
    <div class="modal-dialog modal-dialog-centered">    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>        
        </div>
        <div class="modal-body">
         <div class="bank1">
         <!-- Copy & Pasted from YouTube -->
         <img src="<?php echo site_url();?>/wp-content/uploads/2019/11/boc1.png"/>
       </div>   
        </div>       
      </div>      
    </div>
</div>
<div class="modal fade" id="myModalsampath" role="dialog">
    <div class="modal-dialog modal-dialog-centered">    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>        
        </div>
        <div class="modal-body">
         <div class="bank1">
         <!-- Copy & Pasted from YouTube -->
         <img src="<?php echo site_url();?>/wp-content/uploads/2019/11/Hit-Ad-Double-Spread-2-01.jpg"/>
       </div>   
        </div>       
      </div>      
    </div>
</div>
<div class="modal fade" id="myModalseylan" role="dialog">
    <div class="modal-dialog modal-dialog-centered">    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>        
        </div>
        <div class="modal-body">
         <div class="bank1">
         <!-- Copy & Pasted from YouTube -->
         <img src="<?php echo site_url();?>/wp-content/uploads/2019/11/seylan.png"/>
       </div>   
        </div>       
      </div>      
    </div>
</div>
<div class="modal fade" id="myModalsampathf" role="dialog">
    <div class="modal-dialog modal-dialog-centered">    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>        
        </div>
        <div class="modal-body">
         <div class="bank1">
         <!-- Copy & Pasted from YouTube -->
         <img src="<?php echo site_url();?>/wp-content/uploads/2019/11/siyapatha-finance-1.png"/>
       </div>   
        </div>       
      </div>      
    </div>
</div>
<div class="modal fade" id="myModalsinger" role="dialog">
    <div class="modal-dialog modal-dialog-centered">    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>        
        </div>
        <div class="modal-body">
         <div class="bank1">
         <!-- Copy & Pasted from YouTube -->
           <img src="<?php echo site_url();?>/wp-content/uploads/2019/11/singer-finance.png"/>
       </div>   
        </div>       
      </div>      
    </div>
</div>
<script>

$("#float-call").click(function(){
  $("#myDIV-num").toggle();
});
	

$("#myModalhnb").on('hidden.bs.modal', function (e) {
    $("#myModalhnb iframe").attr("src", $("#myModalhnb iframe").attr("src"));
});
$("#myModalboc").on('hidden.bs.modal', function (e) {
    $("#myModalboc iframe").attr("src", $("#myModalboc iframe").attr("src"));
});
$("#myModalsampath").on('hidden.bs.modal', function (e) {
    $("#myModalsampath iframe").attr("src", $("#myModalsampath iframe").attr("src"));
});
$("#myModalseylan").on('hidden.bs.modal', function (e) {
    $("#myModalseylan iframe").attr("src", $("#myModalseylan iframe").attr("src"));
});
$("#myModalsampathf").on('hidden.bs.modal', function (e) {
    $("#myModalsampath iframe").attr("src", $("#myModalsampath iframe").attr("src"));
});
$("#myModalsinger").on('hidden.bs.modal', function (e) {
    $("#myModalseylan iframe").attr("src", $("#myModalseylan iframe").attr("src"));
});	
</script>

