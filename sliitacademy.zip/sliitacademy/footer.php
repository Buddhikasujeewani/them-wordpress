 <?php echo do_shortcode('[instagram-feed num=8]');?>

<section id="footer-sec" class="nor-text" style="position:relative;">

 

    <div class="container-fluid">

    	<div id="footer-content " class="text-set1  pb-5" style="position:relative;color:#fff;padding:20px;">

		 <div class="row row2">

			 <div class="col-12 col-lg-3">

				 <h4 class="header-1 mb-4">About Us</h4>

			  	 <div class="footer-disc">
                    <img class="footer-logo" src="<?php echo site_url();?>/wp-content/uploads/2020/07/footer-logo.png"/>
                    <p>Beginning the journey in 2014, Wise Homes are pioneering in Real Estate industry by providing luxury residencies 

					constructed with branded materials, professionalism and decades of experience, to upgrade the quality of lives of our customers.  </p>

                 </div>	

			 </div>
			 <div class="col-12 col-lg-3">

				 <h4 class="header-1 mb-4">Quick Links</h4>

			  	  <?php wp_nav_menu(

                      array(

                        'theme_location'  => 'primary',

                        'container_class' => '',

                        'container_id'    => '',

                        'menu_class'      => '',

                        'fallback_cb'     => '',

                        'menu_id'         => 'primary-footer',

                        'walker'          => new WP_Bootstrap_Navwalker(),

                      )

                  ); ?>

			 </div>

			 <div class="col-12 col-lg-3">

	 			   <h4 class="header-1 mb-4">Contact Us</h4>

				   <div class="row m-t-40">

					<div class="col-12 col-md-12 set-text-left">

						<div class="row r-f-space no-gutters">

							<div class="col-lg-2">

							 <i class="fa fa-map-marker"></i>

							</div>

							<div class="col-lg-10 font-s">

									<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar("Address Area") ) : ?>

								    <?php endif;?>



							</div>

						</div>

				   </div>

				  <div class="col-12 col-md-12 set-text-left">

					<div class="">

						<span></span>

						
						<div class="row r-f-space no-gutters">

							<div class="col-lg-2">

							  <i class="fa fa-phone"></i>

							</div>

							<div class="col-lg-10 font-s">

								  <div> <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar("Phone Number") ) : ?>

                                         <?php endif;?>  </div>

					        </div>

						</div>

						<div>

						

						</div>

					</div>

					 
						<div class="row r-f-space no-gutters">

							<div class="col-lg-2">

							    <i class="fa fa-envelope"></i>

							</div>

							<div class="col-lg-10 font-s">

								<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar("email") ) : ?>

									<?php endif;?> 

					           

							</div>

						</div>

					

					</div>

				  </div>

				 			  

		        </div> 

				 <div class="col-12 col-lg-3">

				    <h4>Newsletter</h4>

					<div class="subs-text">

						Subscribe to our newsletter <br> For exclusive updates

					</div> 

					<div>

					    <?php echo do_shortcode('[contact-form-7 id="208" title="subscribe"]');?>

					</div>

					<div>

					   <div class="font-a-wrapper-footer">

							 <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar("Social Media") ) : ?>

			                                  <?php endif;?> 
                                                        


			          </div>

					</div>

				</div>			  

	          </div>

			  <div class="row">

			  <div class="col-12 text-center">

			      

				  </div>

			  </div>

			 </div>

		 </div>

	 </section>

<section id="foot">

<div class="footer-text">

	Copyright © <?php echo date("Y") ?> - <a href="#">Homelands </a> - All Rights Reserved,Concept, Design and Development by <a href="https://www.weblankan.com/">Weblankan.</a>

			</div> 

</section>

<div class="button-set">
	<div class="row">
		<div class="col-12 col-md-4">
			<div class="button-div grow"><p>Pay Online Now</p></div>
		</div>
		<div class="col-12 col-md-4">
			<a href="reservation-form"><div class="button-div grow"><p>Reserve Now</p></div></a>
		</div>
                <div class="col-12 col-md-4">
			<!--div class="button-div grow"><p>Chat Bot</p></div-->
		</div>

	</div>
</div>

<div class="button-set1">
	<div class="row">
		<div class="col-12 col-md-12">
			<a href="https://api.whatsapp.com/send?phone=94710299400&text=Hello%20from%20Homelands"><img class="side-set grow" src="<?php echo site_url();?>/wp-content/uploads/2020/07/whattsapp.png"/>               </a>
		</div>
		<div class="col-12 col-md-12">
			<a href="viber://add?number=94710299400"><img class="side-set grow" src="<?php echo site_url();?>/wp-content/uploads/2020/07/viber.png"/>  </a>
		</div>
        <div class="col-12 col-md-12">			
			<a href="tel:+94710299400"><img class="side-set grow" src="<?php echo site_url();?>/wp-content/uploads/2020/07/call-2.png"/></a>
		</div>
		 <!--div class="col-12 col-md-12">
			<a href="tel:+94710299400"><img class="side-set grow" src="<?php echo site_url();?>/wp-content/uploads/2020/07/imo.png"/></a>
		</div-->
		<div class="col-12 col-md-12">
			<a href="https://www.facebook.com/HomeLands.SL/"><img class="side-set grow" src="<?php echo site_url();?>/wp-content/uploads/2020/07/messanger.png"/></a>
		</div>

	</div>
</div>
<script>
 $(function() {
	AOS.init({
  duration: 100,
		 once: true
})


});
</script>