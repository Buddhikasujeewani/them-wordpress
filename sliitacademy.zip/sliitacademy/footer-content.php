 
<section id="footer-sec" class="nor-text" style="position:relative;">
	<div class="add-mountain">
	<img src="<?php echo site_url("wp-content/uploads/2019/05/footer-top.png") ?>"/>
	</div>

    <div class="container">
     
    

     <div id="footer-content " class="text-set1  pb-5" style="position:relative;color:#fff;padding:20px;">
		 <div class="row row2">
			 <div class="col-12 col-lg-4">
				 <h4 class="header-1 mb-4">Subscribe To NewsLetters</h4>
			  	 <div class="set-margin-bottom-1">Hit the subscribe button to receive many interesting newsletters regarding our scope of service. </div>
				 <?php
               if (function_exists("add_formcraft_form")) {
                 add_formcraft_form("[fc id='1' align='left'][/fc]");
                 }
              ?>		 
              <?php wp_nav_menu(
                              array(
                               'theme_location'  => 'footer_menu',
                               'container_class' => 'footer-menu-class',
                               'container_id'    => '2',
                               'menu_class'      => '3',
                               'fallback_cb'     => '',
                               'menu_id'         => 'footer_ul',
                               'walker'          => new understrap_WP_Bootstrap_Navwalker(),
                              )
                       ); ?>
			<div class="footer-text">
				Copyright © <?php echo date("Y") ?> - <a href="#">Mike Leisure </a> - All Rights Reserved.Concept, Design & Development by <a href="https://www.weblankan.com/">Web Lankan</a>
			</div> 
			
			 </div>
			 <div class="col-12 col-lg-4">
			     <div class="" style="color:#fff!important;">
					<a href=""> <div class="add-book-btn"> Book Now </div></a>
		                 
			 </div> 
			 <div class="row m-t-40">
					<div class="col-12 col-md-4">
						hhhty
				 </div>
				 <div class="col-12 col-md-8 set-text-left font-s">
						Mike Leisure is a hotel for backpackers who seek to gain the real local experience with the capacity for many adventures hovering within its whereabouts. With many facilities that suit guest expectations, it is considered as one of the best hotels that have easy access to many tourist attractions.
				 </div>
		     </div> 
				 </div>
			  <div class="col-12 col-lg-4">
	 			   <h4 class="header-1 mb-4">Contact Us</h4>
				   <div class="row m-t-40">
					<div class="col-12 col-md-6">
						<div class="row">
							<div class="col-md-3">
							   <img src="http://192.168.8.101:2020/2019/May/MikeLeisure/wp-content/uploads/2019/05/location.png"/>
							</div>
							<div class="col-md-9 font-s">
									Mal Waththa, Rambukkana, Sri Lanka.
							</div>
						</div>
				   </div>
				  <div class="col-12 col-md-6 set-text-left">
					<div class="">
						<span></span>
						<div class="row">
							<div class="col-md-3">
							   <img src="http://192.168.8.101:2020/2019/May/MikeLeisure/wp-content/uploads/2019/05/location.png"/>
							</div>
							<div class="col-md-9 font-s">
								  <div><a href="tel:+94718547186">+94 71 85 47 186</a>  </div>
					             <div><a href="tel:+94352265124">+94 35 22 65 124</a>  </div>
							</div>
						</div>
						<div>
						
						</div>
					</div>
					  <div class="row">
							<div class="col-md-3">
							   <img src="http://192.168.8.101:2020/2019/May/MikeLeisure/wp-content/uploads/2019/05/location.png"/>
							</div>
							<div class="col-md-9 font-s">
								  <div><a href="mailto:manager@mikeleisure.com">manager@mikeleisure.com</a>   </div>
					           
							</div>
						</div>
					
					</div>
				  </div>
				  <div class="row m-t-40">
					  <div class="col-12">
					     <a href="https://www.facebook.com/Natural-Latex-USA-401966490386028/?modal=admin_todo_tour"><span class="footer-social"><i class="fa fa-facebook"></i></span>  </a> 
                         <a href="https://www.youtube.com/channel/UCnO1kLk2e9vTu9ZatKsz47Q"> <span class="footer-social"><i class="fa fa-youtube-play"></i></span></a>
                         <a href="https://www.linkedin.com/company/natural-latex-usa-srilanka/"><span class="footer-social"><i class="fa fa-twitter"></i></span></a>
					  </div>
     
       
      </div>
				   <div class="row m-t-40">
					<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3957.274446839939!2d80.39862041525183!3d7.323038815382287!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ae315d078d02f05%3A0xab4aca12c9bb056c!2sMike+Leisure!5e0!3m2!1sen!2slk!4v1557405560538!5m2!1sen!2slk" width="100%" height="150" frameborder="0" style="border:0" allowfullscreen></iframe>
				  
				  </div>
		        </div> 
	          </div>
			 </div>
		 </div>
	 </section>




