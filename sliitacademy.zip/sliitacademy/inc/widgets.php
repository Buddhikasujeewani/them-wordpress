<?php

/**

 * Register widget area.

 *

 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar

 */
function homeland_widgets_init() { 

    register_sidebar( array(

        'name' => __( 'Address Area', 'homeland' ),

        'id' => 'address',

        'description' => __( 'Shows Address in the Autoland website', 'autoland' ),

        'before_widget' => '<div id="%1$s" class="widget %2$s">',

        'after_widget' => '</div>',

        'before_title' => '<h3 class="widget-title">',

        'after_title' => '</h3>',

    ) );

 

    register_sidebar( array(

        'name' =>__( 'Phone Number', 'homeland'),

        'id' => 'Phone',

        'description' => __( 'Shows Phone Numbers in the header website', 'autoland' ),

        'before_widget' => '<div id="%1$s" class="widget %2$s">',

        'after_widget' => '</div>',

        'before_title' => '<h3 class="widget-title">',

        'after_title' => '</h3>',

    ) );

	register_sidebar( array(

        'name' =>__( 'Email', 'homeland'),

        'id' => 'Email',

        'description' => __( 'Shows Email in the homelands website', 'autoland' ),

        'before_widget' => '<div id="%1$s" class="widget %2$s">',

        'after_widget' => '</div>',

        'before_title' => '<h3 class="widget-title">',

        'after_title' => '</h3>',

    ) );
	   register_sidebar( array(

        'name' =>__( 'Phone Number Footer', 'homeland'),

        'id' => 'Phone_footer',

        'description' => __( 'Shows Phone Numbers in the footer website', 'homeland' ),

        'before_widget' => '<div id="%1$s" class="widget %2$s">',

        'after_widget' => '</div>',

        'before_title' => '<h3 class="widget-title">',

        'after_title' => '</h3>',

    ) );
       register_sidebar( array(

        'name' =>__( 'Social Media', 'homeland'),

        'id' => 'Social_media',

        'description' => __( 'Shows social media links in the website', 'homeland' ),

        'before_widget' => '<div id="%1$s" class="widget %2$s">',

        'after_widget' => '</div>',

        'before_title' => '<h3 class="widget-title">',

        'after_title' => '</h3>',

    ) );


	

    }

 

add_action( 'widgets_init', 'homeland_widgets_init' );