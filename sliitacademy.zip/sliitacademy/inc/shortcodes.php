<?php

function home_banners_function()
{

    $args = array('post_type' => 'home_page_banner', 'order' => 'ASC', 'posts_per_page' => -1);
    $loop = new WP_Query($args);
    ob_start();
    if ($loop->have_posts()) :
        while ($loop->have_posts()) : $loop->the_post();
            ?>
            <div class="owl-item">
			<div class="item">
	           <div class="item-description">
	      		   <h2 class="h2-size-common" data-aos="flip-right"><span class="diff-color"><?php echo get_field('colored_header_');?></span> <?php echo get_field('white_colored_header');?></h2>	
	      		   <h4 class="common-h4"><h4 class="common-h4"> <?php echo get_field('small_header');?></h4>
	     		   <p> <?php echo get_field('description');?></p>
	    		   
		      </div>
		      <div class="banner-home-img" style="background-image:url(<?php echo get_field('home_banner');?>);"></div>
        	</div>
        </div>      
           
           
        <?php
    endwhile;
endif;
wp_reset_query();
return ob_get_clean();
}
 add_shortcode('home_banners', 'home_banners_function');
function advertisement_function()
{

    $args = array('post_type' => 'advertisement', 'order' => 'ASC', 'posts_per_page' => -1);
    $loop = new WP_Query($args);
    ob_start();
    if ($loop->have_posts()) :
        while ($loop->have_posts()) : $loop->the_post();
            ?>
            <div class="owl-item">
                <div class="item">
                    <div class="banner-home-imgb" style="background-image:url(<?php echo get_field('ad_image');?>);"></div>
                </div>
             </div>     
           
           
        <?php
    endwhile;
endif;
wp_reset_query();
return ob_get_clean();
}
 add_shortcode('advertisement', 'advertisement_function');
 
function lands_top_function()
{

    $args = array('post_type' => 'land', 'order' => 'DESC', 'posts_per_page' => 3);
    $loop = new WP_Query($args);
    ob_start();
    if ($loop->have_posts()) :
        while ($loop->have_posts()) : $loop->the_post();
            ?>
           <div class="col-12 col-md-6 col-lg-4">
 			    <div class="inner-land">
 			    	<?php $status = get_field('status');

                      if($status == "Available"){
                      	?>
                      	<div class="aval"></div>
                      	<?php
                       }
                       else{
                       	?>
                       <div class="sold"></div>	
                       <?php }
 			    	?>
 			    	
			  	    <div class="inner-border"></div>
			  	    <?php $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' ); ?>
			     	<div class="inner-land-img" style="background-image:url(<?php echo $image[0]; ?>);">
			     		<div class="inner-m-l"></div>
			     		<div class="land-logo"><img src="<?php echo get_field('land_icon');?>"/></div>
			     	</div>
			     	<div class="inner-text">
				     	
				     	<div class="row row">
				     		<div class="col-12"><img src="http://homlands.weblankan.site/wp-content/uploads/2020/07/location-1.png"/></div>
				     		
				     	</div>
				     	<div class="row">
				     		<div class="col-12"><h4> <?php echo get_the_title();?> - <?php echo get_field('land_location');?></h4></div>
				     		
				     	</div>
				     	<div class="row">
				     		<div class="col-2"><img src="http://homlands.weblankan.site/wp-content/uploads/2020/06/money.png"/></div>
				     		<div class="col-10 text-left"><p>LKR <?php $format = number_format(get_field('price_per_perch'), 0, '', ', '); echo $format; ?>  Onwards</p></div> 
				     	</div>
				     	<div class="row">
				     		<div class="col-2"><img src="http://homlands.weblankan.site/wp-content/uploads/2020/07/plot.png"/></div>
				     		<div class="col-10 text-left"><p>Total Blocks <?php echo get_field('total_plots');?></p> </div>
				     	</div>
			     	</div>
			     	<a id="link-style" href="<?php the_permalink() ?>" rel="bookmark"><strong>Read more <i class="fa fa-arrow-right"></i></strong></a>			  	
			   </div>
            </div>     
           
           
        <?php
    endwhile;
endif;
wp_reset_query();
return ob_get_clean();
}
 add_shortcode('lands_top', 'lands_top_function');

function lands_bot_function()
{

$query = new WP_Query($args);
    $args = array('post_type' => 'land', 'order' => 'DESC', 'posts_per_page' => 6,
	'meta_query'    => array(	
        array(
           'key'       => 'status',
           'value'     => 'Available',
           'compare'   => '=',
        ),		
    )
   );
   
    $loop = new WP_Query($args);
	//echo'<pre>';
	//print_r($loop);
	//echo'</pre>';
	
    ob_start();
    if ($loop->have_posts()) :
        while ($loop->have_posts()) : $loop->the_post();
            ?>
           <div class="col-12 col-md-6 col-lg-4">
 			    <div class="inner-land">
 			    	<?php $status = get_field('status');

                      if($status == "Available"){
                      	?>
                      	<div class="aval"></div>
                      	<?php
                       }
                       else{
                       	?>
                       <div class="sold"></div>	
                       <?php }
 			    	?>
 			    	
			  	    <div class="inner-border"></div>
			  	    <?php $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' ); ?>
			     	<div class="inner-land-img" style="background-image:url(<?php echo $image[0]; ?>);">
			     		<div class="inner-m-l"></div>
			     		<div class="land-logo"><img src="<?php echo get_field('land_icon');?>"/></div>
			     	</div>
			     	<div class="inner-text">
				     	
				     	<div class="row row">
				     		<div class="col-12"><img src="http://homlands.weblankan.site/wp-content/uploads/2020/07/location-1.png"/></div>
				     		
				     	</div>
				     	<div class="row">
				     		<div class="col-12"><h4> <?php echo get_the_title();?> - <?php echo get_field('land_location');?></h4></div>
				     		
				     	</div>
				     	<div class="row">
				     		<div class="col-2"><img src="http://homlands.weblankan.site/wp-content/uploads/2020/06/money.png"/></div>
				     		<div class="col-10 text-left"><p>LKR <?php $format = number_format(get_field('price_per_perch'), 0, '', ', '); echo $format; ?>  Onwards</p></div> 
				     	</div>
				     	<div class="row">
				     		<div class="col-2"><img src="http://homlands.weblankan.site/wp-content/uploads/2020/07/plot.png"/></div>
				     		<div class="col-10 text-left"><p>Total Blocks <?php echo get_field('total_plots');?></p> </div>
				     	</div>
			     	</div>
			     	<a id="link-style" href="<?php the_permalink() ?>" rel="bookmark"><strong>Read more <i class="fa fa-arrow-right"></i></strong></a>			  	
			   </div>
            </div>     
           
           
        <?php
    endwhile;
endif;
wp_reset_query();
return ob_get_clean();
}
 add_shortcode('lands_bot', 'lands_bot_function');
function testi_function()
{

    $args = array('post_type' => 'home_page_banner', 'order' => 'ASC', 'posts_per_page' => -1);
    $loop = new WP_Query($args);
    ob_start();
    if ($loop->have_posts()) :
        while ($loop->have_posts()) : $loop->the_post();
            ?>
            <div class="owl-item">
			<div class="item">
	           <div class="item-description">
	      		   <h2 class="h2-size-common" data-aos="flip-right"><span class="diff-color"><?php echo get_field('colored_header_');?></span> <?php echo get_field('white_colored_header');?></h2>	
	      		   <h4 class="common-h4"><h4 class="common-h4"> <?php echo get_field('small_header');?></h4>
	     		   <p> <?php echo get_field('description');?></p>
	    		   
		      </div>
		      <div class="banner-home-img" style="background-image:url(<?php echo get_field('home_banner');?>);"></div>
        	</div>
        </div>      
           
           
        <?php
    endwhile;
endif;
wp_reset_query();
return ob_get_clean();
}
 add_shortcode('home_banners', 'testi_function');
function news_home_function()
{

    $args = array('category_name' => 'news-events', 'order' => 'ASC', 'posts_per_page' => 3);
    $loop = new WP_Query($args);
    ob_start();
    if ($loop->have_posts()) :
        while ($loop->have_posts()) : $loop->the_post();
            ?>
           <div class="col-12 col-md-6 col-lg-4 text-center">
                <div class="inner-land"> 
                    <?php $thumbnail = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID),'full',false );?>                 
                    <div class="inner-land-img" style="background-image:url('<?php echo $thumbnail[0]?>');"></div>                  
                    <div class="row">
                        <div class="col-4">
                            <div class="date-1">
                                
                                <p><?php echo get_the_date(); ?></p>
                            </div>
                        </div>
                        <div class="col-8 text-left">
                             <p class="p-height"><strong><?php echo get_the_title();?></strong></p>


                        </div>
                    </div>
                    <div class="row">                       
                        <div class="col-12 text-left"><p><?php echo substr(get_the_content(), 0, 200); ?>..</p></div>
                    </div>
                    <div class="row">   
                       <a id="link-style" href="<?php the_permalink() ?>" rel="bookmark"><strong>Read more <i class="fa fa-arrow-right"></i></strong></a>
                    </div>
              </div>
            </div>   
           
           
        <?php
    endwhile;
endif;
wp_reset_query();
return ob_get_clean();
}
 add_shortcode('news_home', 'news_home_function');
function news_function()
{

    $args = array('category_name' => 'news-events', 'order' => 'ASC', 'posts_per_page' => -1);
    $loop = new WP_Query($args);
    ob_start();
    if ($loop->have_posts()) :
        while ($loop->have_posts()) : $loop->the_post();
            ?>
           <div class="col-12 col-lg-4 text-center">
                <div class="inner-land"> 
                    <?php $thumbnail = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID),'full',false );?>                 
                    <div class="inner-land-img" style="background-image:url('<?php echo $thumbnail[0]?>');"></div>                  
                    <div class="row">
                        <div class="col-4">
                            <div class="date-1">
                                
                                <p><?php echo get_the_date(); ?></p>
                            </div>
                        </div>
                        <div class="col-8 text-left">
                            <p class="p-height"><strong><?php echo get_the_title();?></strong></p>


                        </div>
                    </div>
                    <div class="row">                       
                        <div class="col-12 text-left"><p><?php echo substr(get_the_content(), 0, 200); ?>..</p></div>
                    </div>
                    <div class="row">   
                       <a id="link-style" href="<?php the_permalink() ?>" rel="bookmark"><strong>Read more <i class="fa fa-arrow-right"></i></strong></a>
                    </div>
              </div>
            </div>   
           
           
        <?php
    endwhile;
endif;
wp_reset_query();
return ob_get_clean();
}
 add_shortcode('news', 'news_function');
function lands_function()
{

 $loop = new WP_Query( array( 'post_type' => 'land', 'paged' => $paged ) );
    if ( $loop->have_posts() ) :
        while ( $loop->have_posts() ) : $loop->the_post(); ?>
	        
	 <?php endwhile;
       
    endif;
}
function payment_function()
{

    $args = array('post_type' => 'payment_terms', 'order' => 'ASC', 'posts_per_page' => -1);
    $loop = new WP_Query($args);
    ob_start();
    if ($loop->have_posts()) :
        while ($loop->have_posts()) : $loop->the_post();
            ?>
            <div class="col-12 col-lg-3">
                    <div class="inner-pay" data-aos="flip-down">                      
                        <div class="circle"></div>
                        <div class="circle-1"></div>
                        <div class="point-num">
                            <p>Plan</p>
                            <p class="num"><?php echo get_field('plan_no');?></p>
                        </div>
                        <div class="inner-rect"></div>
						<h3 id="header-d" class="h2-size-common"><span class="diff-color"><?php echo get_the_title();?></span></h3>
                        
							<?php
							if( have_rows('plan_description') ):
						        while ( have_rows('plan_description') ) : the_row();
	                         ?>
						    <div id="inner-ul" class="row">
							   <div class="col-2 col-md-2"><i class="fa fa-circle"></i></div>
							   <div class="col-10 col-md-10"><?php echo the_sub_field('point');?></div>
							</div>  
                         
							<?php
								   endwhile;
								   else :
								   endif;

                            ?>	 
                      
                    </div>                  
               </div>
           
           
        <?php
    endwhile;
endif;
wp_reset_query();
return ob_get_clean();
}
 add_shortcode('payment_function', 'payment_function');
function career_function()
{

    $args = array('post_type' => 'career', 'order' => 'ASC', 'posts_per_page' => -1);
    $loop = new WP_Query($args);
    ob_start();
    if ($loop->have_posts()) :
        while ($loop->have_posts()) : $loop->the_post();
            ?>
                     
				<section id="career-s-1">
					  <div class="container m-t-40 m-b-50">
						<div class="row no-gutters">
						  <div class="col-12 text-center m-b-50">
						   <h2 id="header-d" class="h2-size-common"><span class="diff-color">We are</span> Hiring</h2> 
							 <h4 class="common-h4">Find your perfect home!</h4>    
						   <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis.</p>
						  </div> 
						 </div> 
						   <div class="row">
								<div class="col-md-3">
									<!-- Tabs nav -->
									<div class="nav flex-column nav-pills nav-pills-custom" id="v-pills-tab" role="tablist" aria-orientation="vertical">
									     <a class="nav-link mb-3 shadow active" id="v-pills-home-tab" data-toggle="pill" href="#v-pills-home" role="tab" aria-controls="v-pills-home" aria-selected="true">
										<i class="fa fa-user-circle-o mr-2"></i>
										<span class="font-weight-bold small text-uppercase"><?php echo get_the_title();?></span></a>  
									</div>
								</div>


								<div class="col-md-9">
									<!-- Tabs content -->
									<div class="tab-content" id="v-pills-tabContent">
										<div class="tab-pane fade shadow rounded bg-white show active p-5" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
										   <img style="width:100%" src="http://homlands.weblankan.site/wp-content/uploads/2020/07/ad.png"/>
										</div>

									</div>
								</div>
							</div>  
						</div>
                 </section>

           
        <?php
    endwhile;
endif;
wp_reset_query();
return ob_get_clean();
}
 add_shortcode('career', 'career_function');
function branch_function()
{

    $args = array('post_type' => 'office_branches', 'order' => 'ASC', 'posts_per_page' => -1);
    $loop = new WP_Query($args);
    ob_start();
    if ($loop->have_posts()) :
        while ($loop->have_posts()) : $loop->the_post();
            ?>
           <div id="inner-row" class="row no-gutters">
        <div class="col-12 col-lg-5 text-center m-b-50">
          <div class="associate-img" style="background-image:url(<?php echo get_field('branch_photo');?>);"></div>    
        </div>
        <div id="" class="inner-shadow col-12 col-lg-7 set-text-left m-b-50">
             <h3 class="h3-size-common"> <?php echo get_the_title();?> Branch</h3> 
            
               <div id="br-row" class="row">
                <div class="col-12 col-lg-2">
                 <i class="fa fa-user" aria-hidden="true"></i>
               </div>
                  <div class="col-12 col-lg-10">
                 <p>Branch Manager : <?php echo get_field('branch_manager');?></p>
               </div>
             </div>
			 <div id="br-row" class="row">
               <div class="col-12 col-lg-2">
                 <i class="fa fa-building" aria-hidden="true"></i>
               </div>
               <div class="col-12 col-lg-10">
                 <p>Address : <?php echo get_field('address');?></p>
               </div>
             </div>
             <div id="br-row" class="row">
                 <div class="col-12 col-lg-2">
                <i class="fa fa-phone" aria-hidden="true"></i>
               </div>
                   <div class="col-12 col-lg-10">
                 <p>Manager Contact No : <?php echo get_field('manager_phone');?></p>
               </div>
             </div>
            
             <div id="br-row" class="row">
                 <div class="col-12 col-lg-2">
                <i class="fa fa-fax" aria-hidden="true"></i>
               </div>
                  <div class="col-12 col-lg-10">
                 <p>Tel / Fax : <?php echo get_field('tel_');?></p>
               </div>
             </div>
           
        </div> 
    </div>    
           
           
        <?php
    endwhile;
endif;
wp_reset_query();
return ob_get_clean();
}
 add_shortcode('branch', 'branch_function');

function branchp_function()
{

    $args = array('post_type' => 'office_branches', 'order' => 'ASC', 'posts_per_page' => -1);
    $loop = new WP_Query($args);
    ob_start();
    if ($loop->have_posts()) :
        while ($loop->have_posts()) : $loop->the_post();
            ?>
          
       
        <div id="" class="inner-shadow col-12 col-lg-4 set-text-left m-b-50">
             <h5 class="h3-size-common" style="color:#fff!important;"> <?php echo get_the_title();?> Branch</h5> 
            
             <div id="br-row" class="row">
                <div class="col-12 col-lg-2">
                 <i class="fa fa-user" aria-hidden="true"></i>
               </div>
                 <div class="col-12 col-lg-10">
                 <p>Branch Manager <br/> <?php echo get_field('branch_manager');?></p>
               </div>
             </div>
             <div id="br-row" class="row">
               <div class="col-12 col-lg-2">
                 <i class="fa fa-building" aria-hidden="true"></i>
               </div>
               <div class="col-12 col-lg-10">
                 <p>Address <br/> <?php echo get_field('address');?></p>
               </div>
             </div>
             <div id="br-row" class="row">
                <div class="col-12 col-lg-2">
                <i class="fa fa-phone" aria-hidden="true"></i>
               </div>
                 <div class="col-12 col-lg-10">
                 <p>Manager Contact No <br/> <?php echo get_field('manager_phone');?></p>
               </div>
             </div>
             <div id="br-row" class="row">
                 <div class="col-12 col-lg-2">
                <i class="fa fa-fax" aria-hidden="true"></i>
               </div>
                <div class="col-12 col-lg-10">
                 <p>Tel / Fax <br/> <?php echo get_field('tel_');?></p>
               </div>
             </div>
             
             
        </div> 
   
           
           
        <?php
    endwhile;
endif;
wp_reset_query();
return ob_get_clean();
}
 add_shortcode('branchp', 'branchp_function');
function ad_function()
{

    $args = array('post_type' => 'advertisement', 'order' => 'ASC', 'posts_per_page' => -1);
    $loop = new WP_Query($args);
    ob_start();
    if ($loop->have_posts()) :
        while ($loop->have_posts()) : $loop->the_post();
            ?>
          <div class="owl-item">
                <div class="item">
                    <div class="banner-home-imgb" style="background-image:url(http://homlands.weblankan.site/wp-content/uploads/2020/07/ad-1.png);"></div>
                </div>
             </div>
           
        <?php
    endwhile;
endif;
wp_reset_query();
return ob_get_clean();
}
 add_shortcode('ad', 'ad_function');
 function associate_function()
{

    $args = array('post_type' => 'associate', 'order' => 'ASC', 'posts_per_page' => -1);
    $loop = new WP_Query($args);
    ob_start();
    if ($loop->have_posts()) :
        while ($loop->have_posts()) : $loop->the_post();
            ?>
         <div class="owl-item">
            <div class="item">
                <img src="<?php echo get_field('image');?>"/>
                
            </div>
        </div>     
           
           
        <?php
    endwhile;
endif;
wp_reset_query();
return ob_get_clean();
}
 add_shortcode('associate', 'associate_function');
?>